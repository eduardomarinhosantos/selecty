require('./components/simulacao/App');
require('./components/credenciamento/App');