import axios from "axios";
import React, { Component } from 'react';
import ReactDOM from 'react-dom';
import Listas from './Listas';
import { data } from "jquery";

export default class App extends Component {
    
    constructor(props){

        super(props);

        this.state = {
            eventos: [],
            evento: '',
            periodos: [],
            periodo: '',
            datas: [],
            data: '',
            setores: [],
            setor: '',
            empresas: [],
            empresa: ''
        }        
        this.handleChangeEvento = this.handleChangeEvento.bind(this);
        this.handleChangePeriodo = this.handleChangePeriodo.bind(this);
        this.handleChangeData = this.handleChangeData.bind(this);
        this.handleChangeSetor = this.handleChangeSetor.bind(this);
        this.handleChangeEmpresa = this.handleChangeEmpresa.bind(this);
        
        this.setCleanLoad = this.setCleanLoad.bind(this);
        this.load = this.load.bind(this);

        this.load( 'eventos' );        
    }

    handleChangeEvento( evento ) {
        this.setCleanLoad( 'eventos', evento );
    }
    handleChangePeriodo( periodo ) {
        this.setCleanLoad( 'periodos', periodo );

    }
    handleChangeData( data ) {
        this.setCleanLoad( 'datas', data );
    }
    handleChangeSetor( setor ) {
        this.setCleanLoad( 'setores', setor );
    }
    handleChangeEmpresa( empresa ) {
        this.setState({ empresa: empresa })
    }

    setCleanLoad( nivel, valor ) {

        //Seta o Valor
        let state = {};
        if( nivel == 'setores' ) state[ 'setor' ] = parseInt( valor );
        else state[ nivel.slice(0, -1) ] = valor;

        //Limpa os Combobox a direita
        state = { ...state, empresas: [],  empresa: '' }
        if( nivel && ( [ 'eventos', 'periodo', 'datas' ].includes( nivel ) ) ) 
            state = { ...state, setores: [],  setor: '' }   
        if( nivel && [ 'eventos', 'periodo' ].includes( nivel ) )
            state = { ...state, datas: [], data: '' }  
        if( nivel && nivel == 'eventos' ) 
            state = { ...state, periodos: [], periodo: '' } 

        //Carrega Próximo Combobox
        this.setState( { ...state }, () => {

            // console.log( this.state );
            if( nivel == 'eventos' ) this.load( 'periodos' );
            if( nivel == 'periodos' ) this.load( 'datas' );
            if( nivel == 'datas' ) this.load( 'setores' );
            if( nivel == 'setores' ) this.load( 'empresas' );
        });
    }

    load( nivel ) {

        //Adiciona os Parâmetros necessários
        let params = {}
        if( nivel && [ "periodos", "datas", "setores", "empresas" ].includes( nivel ) )
            params = { ...params, evento: this.state.evento }   
        if( nivel && ( [ 'datas', 'setores', 'empresas' ].includes( nivel ) ) ) 
            params = { ...params, periodo: this.state.periodo }
        if( nivel && [ 'setores', 'empresas' ].includes( nivel ) ) 
            params = { ...params, data: this.state.data }
        if( nivel && nivel == 'empresas' ) 
            params = { ...params, setor: this.state.setor }

        //Executa Chamada ao Endpoint
        axios
            .get( `${ window.location.origin }/credenciar/${ nivel }`, { params } )
            .then(function ( response ) {

                if( nivel == 'eventos') this.setState({ eventos: response.data });
                if( nivel == 'periodos') this.setState({ periodos: response.data });
                if( nivel == 'datas') this.setState({ datas: response.data });
                if( nivel == 'setores') this.setState({ setores: response.data });
                if( nivel == 'empresas') this.setState({ empresas: response.data });

            }.bind( this ))
            .catch( error => alert('Erro ao Buscar '+ nivel.toUpperCase() +' (Temporário)') );
    }

    render() {

        return (
            <>
                <div className="card shadow mb-4">
                    <div className="card-body">
                            
                        {/* Combobox  de Controle */}
                        <div className="form-group row">
                            <select 
                                className="form-control empresa col mr-3 ml-3"
                                value={ this.evento }
                                onChange={ e => this.handleChangeEvento( e.target.value ) }
                            >
                                <option value="">Evento</option>
                                { this.state.eventos && this.state.eventos.map( evento => {
                                    return ( <option value={ evento.id }> { evento.nome }</option> )
                                })}
                            </select>
                            <select 
                                className="form-control evento col mr-3"
                                value={ this.periodo }
                                onChange={ e => this.handleChangePeriodo( e.target.value ) }
                            >
                                <option value="">Período</option>
                                { this.state.periodos && this.state.periodos.map( periodo => {
                                    return ( <option value={ periodo.id }> { periodo.nome }</option> )
                                })}
                            </select>
                            <select 
                                className="form-control setor col mr-3"
                                value={ this.data }
                                onChange={ e => this.handleChangeData( e.target.value ) }
                            >
                                <option value="">Data</option>
                                { this.state.datas && this.state.datas.map( data => {

                                    const arrData = data.split("-");

                                    return ( <option value={ data }> 
                                        { arrData[2] + "/" + arrData[1] + '/' + arrData[0] }
                                    </option> )
                                })}
                            </select>
                            <select 
                                className="form-control setor col mr-3"
                                value={ this.data }
                                onChange={ e => this.handleChangeSetor( e.target.value ) }
                            >
                                <option value="">Setor</option>
                                { this.state.setores && this.state.setores.map( setor => {
                                    return ( <option value={ setor.id }> { setor.nome }</option> )
                                })}
                            </select>
                            <select 
                                name="setor" 
                                className="form-control setor col mr-3"
                                value={ this.data }
                                onChange={ e => this.handleChangeEmpresa( e.target.value ) }
                            >
                                <option value="">Credenciador</option>
                                { this.state.empresas && this.state.empresas.map(empresa => {
                                    return ( <option value={empresa.id }> {empresa.nome }</option> )
                                })}
                            </select>
                        </div>


                        { 
                            this.state.evento && 
                            this.state.periodo && 
                            this.state.data &&
                            this.state.setor && 
                            this.state.empresa &&
                        
                            <Listas 
                                key={ 
                                    this.state.evento +  
                                    this.state.periodo + 
                                    this.state.data +
                                    this.state.setor +  
                                    this.state.empresa 
                                }
                                evento={ this.state.evento }
                                periodo={ this.state.periodo } 
                                data={ this.state.data }
                                setor={ this.state.setor }
                                empresa={ this.state.empresa }
                            />
                        }
                    </div>
                </div>
            </>
        );
    }
}

if (document.getElementById('credenciamento')) {
    ReactDOM.render(<App />, document.getElementById('credenciamento'));
}