import React, { Component } from 'react';
import { validaData, formataData } from './util.js';

export default class Periodo extends Component {

    constructor(props){

        super(props);

        this.state = {
            id: props.id ? props.id : '',
            nome: props.nome ? props.nome : '',
            inicio: props.inicio ? props.inicio : '',
            termino: props.termino ? props.termino : '',
            dias: {},
            erro: ''
        }

        this.handleDataInicio = this.handleDataInicio.bind(this);
        this.handleDataTermino = this.handleDataTermino.bind(this);
    }

    handleDataInicio(data) { 
        
        //Altera / para - para que seja possível as operações de data
        data = data.replace(/\//g, '-'); 
        this.setState( { inicio: data }, () => this.salvarPeriodo() );       
    }

    handleDataTermino(data) { 
        
        //Altera / para - para que seja possível as operações de data
        data = data.replace(/\//g, '-');
        this.setState( { termino: data }, () => this.salvarPeriodo() );                    
    }

    salvarPeriodo() {

        let valida = true;

        if( this.state.inicio && this.state.inicio.length == 10 ) {
            
            if(!validaData(this.state.inicio)) {
                this.setErroRetorna( 'A data de Início é Inválida', {});
                valida = false;
            }
            else {
                this.setState({ erro: '' });
            }
        }

        if( this.state.termino && this.state.termino.length == 10 ) {

            if(!validaData(this.state.termino)) {
                this.setErroRetorna( 'A data de Término é Inválida', {});
                valida = false;
            }
            else {
                this.setState({ erro: '' });
            }
        }

        if( valida && this.state.inicio.length == 10 && this.state.termino.length == 10 ) {

            //Converte Horários para Datetime
            let hoje = new Date();
            const inicio = this.state.inicio.split("-");
            const termino = this.state.termino.split("-");
            const dataInicio = new Date(inicio[2], inicio[1] - 1, inicio[0]);
            const dataTermino = new Date(termino[2], termino[1] - 1, termino[0]);

            if(dataTermino < dataInicio) {
                this.setErroRetorna( 'A data de Término deve ser após a data de Início', {});
            }
            else if(dataInicio < hoje) {
                this.setErroRetorna( 'A data de Início já passou', {});
            }
            else {

                let dias = {};
                const dataInicioLoop = new Date(inicio[2], inicio[1] - 1, inicio[0]);
                const dataTerminoLoop = new Date(termino[2], termino[1] - 1, termino[0]);
                for (var d = dataInicioLoop; d <= dataTerminoLoop; d.setDate(d.getDate() + 1)) {
                    dias[formataData(d)] = { setores: {} }
                }

                //Limpa Erros e retorna Período para o Componente Pai
                this.setErroRetorna('', dias)            
            }            
        }
        if( this.state.termino.length !== 10 ) {            
            this.setErroRetorna('', {});
        }
    }

    setErroRetorna( mensagem, dias ){

        this.setState(
            { erro: mensagem, dias: dias },
            function() { this.props.retornaPeriodo(this.state.id, {  
                inicio: this.state.inicio, 
                termino: this.state.termino, 
                dias: this.state.dias
            })}
        );
    }

    render() {

        return (
            
            <div 
                key={this.state.id} 
                className="card shadow mb-4 p-0 mr-3" 
                style={{ width: '30%' }}>

                <div className="card-header" style={{backgroundColor: '#ccc' }}>
                    { this.state.nome }
                </div>
                <div className="card-body">

                    <div className="alert alert-danger mt-2 mb-4">
                        Ao alterar um período você perde todas as credenciais do mesmo !
                    </div>   
                    
                    <div className="form-group">
                        <label>Data de Início</label>
                        <input 
                            type="text" 
                            className="data form-control"
                            onChange={ (e) => {
                                this.handleDataInicio(e.target.value);
                            }}
                            value={ this.state.inicio ? this.state.inicio.replace(/-/g, '/') : '' }                                                 
                        />
                    </div>
                    <div className="form-group">
                        <label>Data de Término</label>
                        <input 
                            type="text" 
                            className="data form-control"
                            onChange={ (e) => { 
                                this.handleDataTermino(e.target.value) 
                            }}
                            value={ this.state.termino ? this.state.termino.replace(/-/g, '/') : '' }   
                        />
                    </div>                          
                     
                    { this.state.erro != '' &&
                        <span className="ml-2" style={{ color: '#ff726f' }}>
                            { this.state.erro }
                        </span>    
                    }                                            
                </div>
            </div>
        );
    }
}