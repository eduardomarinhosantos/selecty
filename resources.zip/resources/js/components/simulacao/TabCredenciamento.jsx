import React, { Component } from 'react';
import Setor from './Setor';

export default class TabCredenciamento extends Component {

    constructor(props){

        super(props);
            
        this.state = {

            //Combobox
            locais: JSON.parse(document.getElementById('locais').value),
            periodos: JSON.parse(document.getElementById('periodos').value), 
            
            //Variáveis de Controle
            periodo: '',
            data: '',
            setor: ''
        }  
        
        //Binds
        this.handlePeriodo = this.handlePeriodo.bind(this); 
        this.handleData = this.handleData.bind(this); 
        this.handleSetor = this.handleSetor.bind(this); 
        this.retornaSetor = this.retornaSetor.bind(this); 
    }

    //Combobox de Controle da Página
    handlePeriodo(periodo) { 
        this.setState({ periodo: periodo, data: '', setor: '' }); 
    }
    handleData(data) { 
        this.setState({ data: data, setor: '' }); 
    }
    handleSetor(setor) { 
        this.setState({ setor: setor  }); 
    }

    retornaSetor(setor) {
        
        this.props.updateSetor(this.state.periodo, this.state.data, this.state.setor, {
            id: this.state.setor,
            abertura: setor.abertura,
            termino: setor.termino,
            credenciamento_inicio: setor.credenciamento_inicio,
            credenciamento_termino: setor.credenciamento_termino,
            empresas: setor.empresas
        });
    }

    render() {

        let setorCredenciamento = false;
        if(this.state.periodo && this.state.data && this.state.setor) {
            
            setorCredenciamento = this.props
                .periodos[this.state.periodo]
                .dias[this.state.data]
                .setores[this.state.setor];            
        }

        return (

            <div 
                className="card shadow mb-4 col-md-12 p-0">

                {/* HEADER */}
                <div className="card-header">Credenciamento</div>

                {/* COMBOBOXS DE CONTROLE */}
                <div className="card-body" style={{ paddingLeft: '1rem' }}>
                    <div className="row">

                        {/* Período */}
                        <div className="form-group col-md-3">
                            <label>Períodos</label>
                            <select className="form-control" 
                                value={ this.state.periodo } 
                                onChange={ (e) => this.handlePeriodo(e.target.value) }
                            >
                                <option value="" disabled> Selecione </option> 
                                {this.state.periodos.map(periodo => 
                                    <option key={periodo.id} value={periodo.id}>{periodo.nome}</option>
                                )}
                            </select>
                        </div>

                        {/* Data */}
                        { this.state.periodo &&

                            <div className="form-group col-md-3">
                                <label>Data</label>
                                <select className="form-control"
                                    value={ this.state.data } 
                                    onChange={ (e) => this.handleData(e.target.value) }
                                >
                                    <option value="" disabled> Selecione </option>
                                    {
                                        this.props.periodos[this.state.periodo]?.dias && 
                                        Object.keys(
                                            this.props.periodos[this.state.periodo]?.dias
                                        ).map(function(key, index){
                                            return <option key={key} value={key}>{key.replace(/-/g, '/')}</option>
                                        })
                                    }

                                </select>
                            </div>
                        }

                        {/* Setor */}
                        { this.state.periodo && this.state.data && 
                        
                            <div className="form-group col-md-4">
                                <label>Setor</label>
                                <select className="form-control"
                                    value={ this.state.setor } 
                                    onChange={ (e) => this.handleSetor(e.target.value) }
                                >
                                    <option value="" disabled> Selecione </option>
                                    {this.props.local.setores.map(function(setor){
                                        return (<option key={setor.id} value={setor.id}>{setor.nome}</option>)
                                    })}
                                </select>
                            </div>
                        }
                    </div>
                    <hr />
                    
                    {/* DADOS DO SETOR */}
                    {this.state.periodo && this.state.data && this.state.setor &&

                        <Setor 
                            key={ `${this.state.periodo}-${this.state.data}-${this.state.setor}` }
                            abertura={ 
                                setorCredenciamento ? setorCredenciamento.abertura : '' 
                            }
                            termino={ 
                                setorCredenciamento ? setorCredenciamento.termino : '' 
                            }
                            credenciamento_inicio={ 
                                setorCredenciamento ? setorCredenciamento.credenciamento_inicio : '' 
                            }
                            credenciamento_termino={ 
                                setorCredenciamento ? setorCredenciamento.credenciamento_termino : '' 
                            }
                            empresas={ 
                                setorCredenciamento ? setorCredenciamento.empresas : [] 
                            }
                            retornaSetor={ this.retornaSetor }
                        />
                    }
                    <div>
                        <button 
                            onClick={() => this.props.alternaTab(3)} 
                            className="btn btn-success float-right" 
                            style={{ width: '20%', marginLeft : '3%'}}>
                                    Simular Custos                             
                        </button>
                        <button 
                            onClick={() => this.props.alternaTab(1)} 
                            className="btn btn-danger float-right" 
                            style={{ width: '20%', display: 'inline'}}>
                                Alterar Períodos 
                        </button>                                
                    </div>
                </div>                        
            </div>
        )
    }
}