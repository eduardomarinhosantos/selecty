import React, { Component } from 'react';
import { validaHorario, horarioParaSegundos } from './util.js';
import Empresa from './Empresa';


export default class Setor extends Component {

    constructor(props){

        super(props);

        this.state = {

            //Abertura, Término e horários de Credenciamento do Setor
            abertura: props.abertura,
            termino: props.termino,
            credenciamento_inicio: props.credenciamento_inicio,
            credenciamento_termino: props.credenciamento_termino,

            //Lista de Empresas
            empresas: props.empresas,

            //Erros
            erroAberturaTermino: '',
            erroCredenciamento: ''
        }
        
        //Binds
        this.handleAbertura = this.handleAbertura.bind(this);
        this.handleTermino = this.handleTermino.bind(this);
        this.handleCredenciamentoInicio = this.handleCredenciamentoInicio.bind(this);
        this.handleCredenciamentoTermino = this.handleCredenciamentoTermino.bind(this);
        this.handleSalvarSetor = this.handleSalvarSetor.bind(this);
        this.handleAdicionarEmpresa = this.handleAdicionarEmpresa.bind(this);
        this.handleUpdateEmpresas = this.handleUpdateEmpresas.bind(this);
        this.handleRemoveEmpresa = this.handleRemoveEmpresa.bind(this);        
    }

    handleAbertura( abertura ) {
        this.setState(
            { abertura : validaHorario( abertura ) }, 
            () => this.handleSalvarSetor() 
        );
    }
    handleTermino( termino ) {
        this.setState(
            { termino : validaHorario( termino ) }, 
            () => this.handleSalvarSetor() 
        );
    }
    handleCredenciamentoInicio( credenciamento_inicio ) {
        this.setState(
            { credenciamento_inicio : validaHorario( credenciamento_inicio ) }, 
            () => this.handleSalvarSetor() 
        );
    }
    handleCredenciamentoTermino( credenciamento_termino ) {
        this.setState(
            { credenciamento_termino : validaHorario( credenciamento_termino ) }, 
            () => this.handleSalvarSetor() 
        );
    }
    handleAdicionarEmpresa() {
        let empresas = [ ...this.state.empresas ]
        empresas.push({ 
            id: (empresas != 0 && empresas[empresas.length-1]) ? empresas[empresas.length - 1].id + 1 : 1, 
            empresas: '', alimentacao: '', intervalo: '', taxa_unitaria: '', quantidade: '' 
        });
        this.setState({ empresas: empresas }, () => this.handleSalvarSetor());   
    }
    handleUpdateEmpresas( id, empresa ) {
        let empresas = [ ...this.state.empresas ]
        empresas.map( empresaLoop => {
            if(empresaLoop.id == id) {

                empresaLoop.empresa = empresa.empresa;
                empresaLoop.alimentacao = empresa.alimentacao;
                empresaLoop.intervalo = empresa.intervalo;
                empresaLoop.taxa_unitaria = empresa.taxa_unitaria;
                empresaLoop.quantidade = empresa.quantidade;
            }
        });
        this.setState({ empresas: empresas }, () => this.handleSalvarSetor());   
    }
    handleRemoveEmpresa( id ) {
        let empresas = [ ...this.state.empresas ]
        empresas = empresas.filter(function( obj ) {
            return obj.id !== id;
        });
        this.setState({ empresas: empresas }, () => this.handleSalvarSetor());   
    }
    handleSalvarSetor() {

        let valida = true;

        //Validação Abertura / Término
        if( this.state.abertura && this.state.termino ) {

            const abertura = horarioParaSegundos( this.state.abertura ); 
            const termino = horarioParaSegundos( this.state.termino );
      
            //Horário Abertura Maior que Termino
            if( abertura >= termino ) {
                this.setState({ erroAberturaTermino: 'A Abertura deve ser antes do Término' });
                valida = false;
            }
            
            //Limpa Erros
            else {
                this.setState({ erroAberturaTermino: '' });
            }            
        }

        //Validação Credenciamento
        if( this.state.credenciamento_inicio && this.state.credenciamento_termino ) {

            const credenciamento_inicio = horarioParaSegundos( this.state.credenciamento_inicio ); 
            const credenciamento_termino = horarioParaSegundos( this.state.credenciamento_termino );     

            //Horário CredenciamentoInicio Maior que CredenciamentoTermino
            if( credenciamento_inicio >= credenciamento_termino ) {
                this.setState({ erroCredenciamento: 'O Término do Credenciamento deve ser após seu Início' });
                valida = false;
            }

            //Limpa Erros
            else{
                this.setState({ erroCredenciamento: '' });
            }
        }

        //Validação Abertura / Término / Credenciamento
        if( 
            valida && //Caso nenhum das anteriores tenha dado Falso !
            this.state.abertura && this.state.termino && 
            this.state.credenciamento_inicio && this.state.credenciamento_termino
        ) {

            const abertura = horarioParaSegundos( this.state.abertura ); 
            const termino = horarioParaSegundos( this.state.termino );
            const credenciamento_inicio = horarioParaSegundos( this.state.credenciamento_inicio ); 
            const credenciamento_termino = horarioParaSegundos( this.state.credenciamento_termino ); 

            //Horario CredenciamentoInicio Maior que Abertura
            if( credenciamento_inicio < abertura ) {
                this.setState({ erroCredenciamento: 'O Credenciamento deve iniciar após a Abertura do Setor' });
                valida = false;
            }

            //Horário CredenciamentoTermino Menor que Termino
            else if( credenciamento_termino > termino ) {
                this.setState({ erroCredenciamento: 'O Término do Credenciamento deve ser antes do Término do Setor' });
                valida = false;
            }

            //Limpa Erros
            else{
                this.setState({ erroCredenciamento: '', erroAberturaTermino: '' });
            }
        }

        //Caso algum valor não tenha sido setado
        else valida = false;

        if(valida) {
            
            //Retorna Setor para o Componente Pai
            this.props.retornaSetor({
                
                abertura: this.state.abertura,
                termino: this.state.termino,
                credenciamento_inicio: this.state.credenciamento_inicio,
                credenciamento_termino: this.state.credenciamento_termino,
                empresas: this.state.empresas
            });
        }
    }

    render() {

        return (

            <>
                {/* Header */}
                <div className="mb-2 ml-2 mt-5">
                    <span className="fa fa-puzzle-piece mr-2"></span>
                    <strong className="mr-2">Alterar Setor</strong>
                    <i 
                        className="fas fa-fw fa-plus text-primary toggle-evento-setor mt-1" 
                        style={{ color: 'green !important' }}></i>
                </div>

                <div id="novas-empresas-container" className="row" style={{ marginLeft: '1px'}}>
                
                    {/* Horários */}
                    <div className="card col-md-3 mr-3 mb-3 p-0">
                    
                        <div className="card-body" style={{ backgroundColor: "#E8E8E8"}}>

                            <div className="mb-2 mt-4">
                                <strong>Horários</strong>
                            </div>

                            {/* Abertura */}
                            <div className="form-group">
                                <label style={{ display: 'block'}}>Abertura - Término</label>
                                <input 
                                    type="text" 
                                    className="form-control col-md-5 horario" 
                                    style={{ display: 'inline'}} 
                                    value={ this.state.abertura } 
                                    onChange={ e => this.handleAbertura( e.target.value ) }/> 
                                    <span className="ml-2 mr-2">às</span> 
                                <input 
                                    type="text" 
                                    className="form-control col-md-5 horario" 
                                    style={{ display: 'inline'}} 
                                    value={ this.state.termino } 
                                    onChange={ e => this.handleTermino( e.target.value ) }/>

                                { this.state.erroAberturaTermino != '' &&
                                    <div className="mt-1" style={{ color: '#ff726f', fontSize: '14px' }}>
                                        { this.state.erroAberturaTermino }
                                    </div>    
                                } 
                            </div>

                            {/* Credenciamento */}
                            <div className="form-group">
                                <label style={{ display: 'block'}}>Credenciamento</label>
                                <input 
                                    type="text" 
                                    className="form-control col-md-5 horario" 
                                    style={{ display: 'inline'}} 
                                    value={ this.state.credenciamento_inicio } 
                                    onChange={ e => this.handleCredenciamentoInicio( e.target.value ) }/> 
                                    <span className="ml-2 mr-2">às</span> 
                                <input 
                                    type="text" 
                                    className="form-control col-md-5 horario" 
                                    style={{ display: 'inline'}} 
                                    value={ this.state.credenciamento_termino } 
                                    onChange={ e => this.handleCredenciamentoTermino( e.target.value ) }/>

                                { this.state.erroCredenciamento != '' &&
                                    <div className="mt-1" style={{ color: '#ff726f', fontSize: '14px' }}>
                                        { this.state.erroCredenciamento }
                                    </div>    
                                } 
                            </div>                            

                            {/* Adicionar Empresa */}
                            <div className="form-group">
                                <button 
                                    className="btn btn-success btn-block"
                                    onClick={ () => this.handleAdicionarEmpresa() }
                                    disabled={ !( 
                                        this.state.abertura && this.state.termino && 
                                        this.state.credenciamento_inicio && this.state.credenciamento_termino && 
                                        !this.state.erroAberturaTermino && !this.state.erroCredenciamento
                                    ) }>
                                    <span className="fas fa-fw fa-building mr-2"></span>
                                    Adicionar Empresa
                                    <span className="fas fa-fw fa-plus ml-2"></span>                           
                                </button>
                            </div>
                        </div>
                    </div>

                    {/* Empresas no Setor */}
                    { this.state.empresas.map( ( empresa, index ) => {

                        if(empresa) {
                            
                            return (
                                
                                <Empresa 
                                    key={ `${this.state.periodo}-${this.state.data}-${this.state.setor}-${empresa.id}` }
                                    id={empresa.id}
                                    empresa={ empresa.empresa }
                                    alimentacao={ empresa.alimentacao }
                                    intervalo={ empresa.intervalo }
                                    taxa_unitaria={ empresa.taxa_unitaria }
                                    quantidade={ empresa.quantidade }
                                    handleUpdateEmpresas={ this.handleUpdateEmpresas }
                                    handleRemoveEmpresa={ this.handleRemoveEmpresa }
                                />
                            )
                        }

                    })}
                    
                </div>                     
            </>
        );
    }
}