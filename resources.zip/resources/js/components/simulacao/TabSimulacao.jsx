import React, { Component } from 'react';

export default class TabSimulacao extends Component {

    render() {   

        //TODO ADICIONAR UMAS ARRAY FUNCTION BOLADONA
        //VALIDAR TAXAS COM CENTAVOS

        const alimentacoesArray = JSON.parse(document.getElementById('alimentacoes').value);
        const periodos = JSON.parse(document.getElementById('periodos').value);
        
        //Totais por Setor do Local do Evento
        const localSetores = [];
        this.props.credenciamentos.local.setores.map( localSetor => localSetores[localSetor.id] = 0 );

        const totaisPeriodo = [];
        periodos.map( periodo => totaisPeriodo[periodo.id] = 0);

        //Totais por Periodo
        const totaisPeriodoSetor = [];
        totaisPeriodoSetor['periodos'] = [];
        periodos.map( periodo => { 
            totaisPeriodoSetor['periodos'][periodo.id] = {};
            totaisPeriodoSetor['periodos'][periodo.id]['total_efetivo_setor'] = [ ...localSetores ];
            totaisPeriodoSetor['periodos'][periodo.id]['total_alimentacao'] = 0;
            totaisPeriodoSetor['periodos'][periodo.id]['total_taxa_unitaria'] = 0;
            totaisPeriodoSetor['periodos'][periodo.id]['total_efetivo'] = 0;
            totaisPeriodoSetor['periodos'][periodo.id]['total_custo'] = 0;
            totaisPeriodoSetor['total_efetivo_setores'] = [ ...localSetores ];
            totaisPeriodoSetor['total_alimentacao'] = 0;
            totaisPeriodoSetor['total_taxa_unitaria'] = 0;
            totaisPeriodoSetor['total_efetivo'] = 0;
            totaisPeriodoSetor['total_custo'] = 0;
        });

        //Totais por Período e Setor - Coleta Valores
        this.props.credenciamentos.periodos.map( ( periodo, periodoId ) => {

            if(periodo) {   

                //TODO - CORRIGIR ESSA BAGUNÇA DE INDEXES STRING E INT
           
                Object.values(periodo.dias).map( dia => {         
                
                    Object.values(dia.setores).map( (setor) => {
                        
                        setor.empresas?.map( ( empresa ) => {    
                            
                            if( empresa.quantidade ) { 

                                //Efetivo
                                const valorEfetivo = parseInt(empresa.quantidade);
                                totaisPeriodoSetor['periodos'][periodoId]['total_efetivo_setor'][setor.id] += valorEfetivo;
                                totaisPeriodoSetor['periodos'][periodoId]['total_efetivo'] += valorEfetivo;
                                totaisPeriodoSetor['total_efetivo_setores'][setor.id] += valorEfetivo;
                                totaisPeriodoSetor['total_efetivo'] += valorEfetivo;

                                if( empresa.alimentacao ) {

                                    //Alimentação
                                    const alimentacao = alimentacoesArray.filter( 
                                        alimentacao => alimentacao.id == empresa.alimentacao
                                    )                 
                                
                                    const valorAlimentacao = parseInt( empresa.quantidade * alimentacao[0].valor_unitario );           
                                    totaisPeriodoSetor['periodos'][periodoId]['total_alimentacao'] += valorAlimentacao ;
                                    totaisPeriodoSetor['total_alimentacao'] += valorAlimentacao;
                                    totaisPeriodoSetor['periodos'][periodoId]['total_custo'] += valorAlimentacao;
                                    totaisPeriodoSetor['total_custo'] += valorAlimentacao;

                                }

                                //Taxa Unitária
                                if( empresa.taxa_unitaria ) {

                                    const valorTaxaUnitaria = parseInt( empresa.quantidade * empresa.taxa_unitaria );
                                    totaisPeriodoSetor['periodos'][periodoId]['total_taxa_unitaria'] += valorTaxaUnitaria;
                                    totaisPeriodoSetor['total_taxa_unitaria'] += valorTaxaUnitaria;
                                    totaisPeriodoSetor['periodos'][periodoId]['total_custo'] += valorTaxaUnitaria;
                                    totaisPeriodoSetor['total_custo'] += valorTaxaUnitaria;
                                }
                            }
                        });                        
                    })
                });
            }

        });
    
        return (

            <div className="card shadow mb-4 col-md-12 p-0">

                <div className="card-header">Simulação</div>

                <div className="table-responsive">
                    <table className="table table-bordered table-striped" id="dataTable" width="100%" cellSpacing="0">
                        <thead>
                            <tr>
                                <th><strong>Setor / Efetivo</strong></th>
                                { periodos && periodos.map( periodo => 
                                    (<th key={ periodo.id }><strong>{ periodo.nome }</strong></th>)
                                )}
                                <th><strong>Total</strong></th>
                            </tr>
                        </thead>
                        <tbody>
                            
                            { this.props.credenciamentos.local.setores.map( localSetor => 
                                (
                                    <tr>
                                        <td>{ localSetor.nome }</td>
                                        { totaisPeriodoSetor['periodos'].map( periodo => 
                                            <td>{ periodo['total_efetivo_setor'][localSetor.id] }</td>                             
                                        )}
                                        <td>{ totaisPeriodoSetor['total_efetivo_setores'][localSetor.id] }</td>
                                    </tr>
                                )
                            )}   

                            <tr style={{color: "blue"}}>
                                <td><strong>Efetivo Total</strong></td>
                                <>
                                    { totaisPeriodoSetor['periodos'].map( periodo => 
                                        <td>{ periodo['total_efetivo'] }</td>                             
                                    )}
                                    <td>{ totaisPeriodoSetor['total_efetivo'] }</td>
                                </>        
                            </tr>
                            

                            
                        </tbody>
                        
                        <tbody >
                            <tr style={{color: "green"}}>
                                <td><strong>Alimentação</strong></td>
                                { totaisPeriodoSetor['periodos'].map( periodo => 
                                    <td>{ periodo['total_alimentacao'] }</td>                             
                                )}
                                <td>{ totaisPeriodoSetor['total_alimentacao'] }</td>
                            </tr>
                            <tr style={{color: "red"}}>
                                <td><strong>Taxas</strong></td>
                                { totaisPeriodoSetor['periodos'].map( periodo => 
                                    <td>{ periodo['total_taxa_unitaria'] }</td>                             
                                )}
                                <td>{ totaisPeriodoSetor['total_taxa_unitaria'] }</td>
                            </tr>
                        </tbody>
                        <tbody>
                            <tr style={{color: "black"}}>
                                <td><strong>Custo Total Previsto</strong></td>
                                { totaisPeriodoSetor['periodos'].map( periodo => 
                                    <td>{ periodo['total_custo'] }</td>                             
                                )}
                                <td>{ totaisPeriodoSetor['total_custo'] }</td>
                            </tr>                           
                        </tbody>
                    </table>       
                            
                </div>

                <div className="card-body pl-2">
                    <button 
                        className="btn btn-success float-right" 
                        onClick={() => this.props.criarEvento()}
                        style={{ width: '20%', display: 'inline'}}>
                            Criar Evento 
                    </button>   
                    <button 
                        onClick={() => this.props.alternaTab(2)} 
                        className="btn btn-danger float-right mr-2" 
                        style={{ width: '20%', display: 'inline'}}>
                            Credenciar Empresas 
                    </button>            
                </div>                    
            </div>
        )
    }
}