@extends('site.template.main')

@section('conteudo')

@php
    $field = (isset($_GET['field'])) ? $_GET['field'] : '';
    $search = (isset($_GET['search'])) ? $_GET['search'] : '';
@endphp

<!-- Page Heading -->
<p class="mb-4">Lista de todas os Credenciados cadastrados no sistema.</p>

<!-- DataTales Example -->
<div class="card shadow mb-4">
    <div class="card-body">
        <div class="table-responsive">
            <form method="get">
                @csrf
                <div class="row" style="margin: 0px 0px 15px 0px;">
                    <select name="field" class="form-control col-md-5" style="margin-right: 5px;">
                        <option value="" @php if($field == '') echo 'selected'; @endphp >Campo</option>
                        <option value="nome" @php if($field == 'nome') echo 'selected'; @endphp>Nome</option>
                        <option value="rg" @php if($field == 'rg') echo 'selected'; @endphp>RG</option>
                        <option value="cpf_cnpj" @php if($field == 'cpf_cnpj') echo 'selected'; @endphp>CPF</option>
                    </select>
                    <input name="search" type="text" placeholder="Valor" class="form-control col-md-5" value="{{$search}}" style="margin-right: 5px;"></input>
                    <input type="submit" class="btn btn-primary" value="Buscar" />
                </div>
            </form>
            <table class="table table-bordered display" width="100%" cellspacing="0">
                <thead>
                    <tr>
                        <th>Nome</th>
                        <th>CPF / CNPJ</th>
                        <th>RG</th>
                        <th width="5%">Detalhes</th>
                        <th width="5%">Editar</th>
                        <th width="5%">Excluir</th>
                    </tr>
                </thead>
                <tbody>
                    @foreach($registros as $funcionario)
                        <tr>
                            <td>{{ $funcionario->nome }}</td>
                            <td>{{ $funcionario->cpf_cnpj }}</td>
                            <td>{{ $funcionario->rg }}</td>
                            <td class="text-center">
                                <a href="{{ route('site.funcionario.show', $funcionario->id) }}">
                                    <span class="fa fa-eye"></span>
                                </a>
                            </td>
                            <td class="text-center">
                                <a href="{{ route('site.funcionario.edit', $funcionario->id) }}">
                                    <span class="fa fa-pencil-alt"></span>
                                </a>
                            </td>
                            <td class="text-center">
                                {!! Form::open(['route' => ['site.funcionario.destroy', $funcionario->id], 'method' => 'DELETE', 'class' => 'form-deletar', 'data-modulo' => 'funcionario']) !!}
                                    {{ Form::button('<span class="fa fa-trash"></span>', 
                                        ['type' => 'submit', 'style' => 'color:red', 'class'=>"delete-button"] )  
                                    }}                        
                                {!! Form::close() !!}                            
                            </td>
                        </tr>
                        @endforeach
                </tbody>
            </table>
            {{ $registros->appends($_GET)->links() }}
        </div>
    </div>
</div>
@endsection 

@section('js')
    <script src="{{ asset('js/adm/funcionario/index-show.js') }}"></script>
@endsection