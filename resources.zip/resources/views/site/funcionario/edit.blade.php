@extends('site.template.main')

@section('conteudo')

<!-- Page Heading -->
<p class="mb-4">Editar Credenciado</p>

<!-- DataTales Example -->
<div class="card shadow mb-4">
    <div class="card-body">
        {!! Form::model($funcionario, ['route' => ['site.funcionario.update', $funcionario->id], 'method' => 'put', 'id' => 'editar', 'autocomplete' => 'off']) !!}
            @include('site.funcionario.fields')
            <div class="form-group">
                {!! Form::submit('Editar', ['class' => 'btn btn-primary float-right']) !!}
            </div>
        {!! Form::close() !!}
    </div>
</div>
@endsection 

@section('js')
    <script src="{{ asset('js/adm/funcionario/create-edit.js') }}"></script>
@endsection