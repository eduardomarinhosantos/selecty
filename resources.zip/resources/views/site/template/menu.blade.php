<ul class="navbar-nav bg-gradient-primary sidebar sidebar-dark accordion" id="accordionSidebar">

    <li class="nav-item">
        <a class="nav-link" href="{{ route('site.empresa.edit',[ 'id' => '1']) }}">
            <i class="fas fa-fw fa-building"></i>
            <span>Perfil</span>
        </a>
    </li>

    <li class="nav-item">
        <a class="nav-link" href="{{ route('site.funcionario.index') }}">
            <i class="fas fa-fw fa-users"></i>
            <span>Credenciados</span>
        </a>
    </li>

    <li class="nav-item">
        <a class="nav-link" href="{{ route('site.credenciar.index') }}">
            <i class="fas fa-fw fa-id-card-alt"></i>
            <span>Credenciar</span>
        </a>
    </li>

    <li class="nav-item">
        <a class="nav-link" href="{{ route('site.evento.index') }}">
            <i class="fas fa-fw fa-calendar"></i>
            <span>Eventos</span>
        </a>
    </li>

    <hr class="sidebar-divider d-none d-md-block">

    <div class="text-center d-none d-md-inline">
        <button class="rounded-circle border-0" id="sidebarToggle"></button>
    </div>

</ul>