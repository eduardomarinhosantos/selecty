
{{--  Variáveis --}}
@php
    $modulo = explode('.', Route::current()->getName())[0];
    if($modulo == 'site'){
        $modulo = explode('.', Route::current()->getName())[0].'.'.explode('.', Route::current()->getName())[1];
        $view   = explode('.', Route::current()->getName())[2];
        if(isset(explode('/', Request::url())[5])) $id = explode('/', Request::url())[5]; 
    }
    else{
        $view   = explode('.', Route::current()->getName())[1];
        if(isset(explode('/', Request::url())[4])) $id = explode('/', Request::url())[4]; 
    }
@endphp
<!DOCTYPE html>
<html lang="en">

    <head>

        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
        <meta name="description" content="">
        <meta name="author" content="">

        <title>TenTickets System</title>

        <!-- Estilos Obrigatórios -->
        <link href="{{ asset('css/fontawesome-free/css/all.min.css') }}" rel="stylesheet" type="text/css">
        <link href="{{ asset('css/sb-admin-2.css') }}" rel="stylesheet">
        <link href="{{ asset('css/custom.css') }}" rel="stylesheet">
        <link href="{{ asset('css/libs/sweetalert2.min.css') }}" rel="stylesheet">

        <!-- Estilos por View-->
        @if($view == 'index' || $view == 'show')
            <link href="{{ asset('css/libs/dataTables.bootstrap4.min.css') }}" rel="stylesheet">
        @endif

        @yield('css')    

    </head>

    <body id="page-top">

        <div id="wrapper">

            <!-- Menu -->
            @include('site.template.menu')

            <div id="content-wrapper" class="d-flex flex-column">

                <div id="content">

                    <!-- Topbar -->
                    @include('site.template.topbar')

                    <!-- Conteúdo -->
                    <div class="container-fluid">

                        <!-- Cabeçalho -->
                        <div class="d-sm-flex align-items-center justify-content-between mb-4">
                            <h1 class="h3 mb-0 text-gray-800">                           

                                @php if($view == 'create') $titulo = 'Novo Registro' @endphp
                                @switch($modulo)
                                    @case('site.empresa')
                                        <i class="fas fa-fw fa-building mr-1 mb-3"></i>
                                        {{ $titulo ?? 'Credenciadores' }}  
                                        @break

                                    @case('site.funcionario')
                                        <i class="fas fa-fw fa-users mr-1"></i>
                                        {{ $titulo ?? 'Credenciados' }}                                
                                        @break

                                    @case('site.evento')
                                        <i class="fas fa-fw fa-calendar mr-1"></i>
                                        {{ $titulo ?? 'Eventos' }}                                
                                        @break

                                    @case('site.credenciar')
                                        <i class="fas fa-fw fa-id-card-alt mr-1"></i>
                                        {{ $titulo ?? 'Credenciar' }}                                
                                        @break
                                @endswitch
                                
                            </h1>
                            @if( 
                                $modulo != 'site.credenciar' && 
                                $modulo != 'site.empresa' && 
                                $modulo != 'site.evento'
                            )
                                <div class="float-right">
                                    @if( $view == 'show' || $view == 'edit' || $view == 'create')
                                        <a href="{{ route($modulo.'.index') }}" class="d-none d-sm-inline-block btn btn-sm btn-warning shadow-sm">
                                            <i class="fas fa-list fa-sm text-white-50"></i> Listar Registros
                                        </a>
                                    @endif
                                    
                                    @if( $view == 'show')
                                        <a href="{{ route($modulo.'.edit', $id) }}" class="d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm">
                                            <i class="fas fa-pencil-alt fa-sm text-white-50"></i> Editar Registro
                                        </a>
                                    @endif
                                    
                                    @if( $view == 'index' || $view == 'edit' || $view == 'show')
                                        <a href="{{ route($modulo.'.create') }}" class="d-none d-sm-inline-block btn btn-sm btn-success shadow-sm">
                                            <i class="fas fa-plus fa-sm text-white-50"></i> Novo Registro
                                        </a>
                                    @endif
                                </div>
                            @endif
                        </div>
                        
                        @yield('conteudo')

                    </div>

                </div>

                <!-- Footer -->
                <footer class="sticky-footer bg-white">
                    <div class="container my-auto">
                    <div class="copyright text-center my-auto">
                        <span>Copyright &copy; TenTickets 2019</span>
                    </div>
                    </div>
                </footer>

            </div>

        </div>

        <!-- Scripts Obrigatórios -->
        <script src="{{ asset('js/libs/jquery-1.11.2.min.js') }}"></script>
        <script src="{{ asset('js/libs/bootstrap.bundle.min.js') }}"></script>
        <script src="{{ asset('js/libs/sb-admin-2.min.js') }}"></script>
        <script src="{{ asset('js/libs/sweetalert2.min.js') }}"></script>

        <!-- Scripts por View-->
        @if($view == 'index' || $view == 'show')
            <script src="{{ asset('js/libs/jquery.dataTables.min.js') }}"></script>
            <script src="{{ asset('js/libs/dataTables.bootstrap4.min.js') }}"></script>
            <script src="{{ asset('js/adm/template/index-show.js') }}"></script>
         @endif

        @if($view == 'edit' || $view == 'create')
            <script src="{{ asset('js/libs/jquery.mask.min.js') }}"></script>
            <script src="{{ asset('js/libs/jquery-validate.min.js') }}"></script>
            <script src="{{ asset('js/libs/additional-methods.js') }}"></script>
        @endif


        @yield('js')
    </body>
</html>