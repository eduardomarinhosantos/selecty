@extends('site.template.main')

@section('conteudo')
<input id="baseurl" type="hidden" value="{{\URL::to('/')}}" />
<meta name="csrf-token" content="{{ csrf_token() }}">
<div class="loading"></div>

<!-- Page Heading -->
<p class="mb-4">Credencia Credenciados por Evento/Setor.</p>

    <div class="card shadow mb-4">
        <div class="card-body">
                
            <!-- Combobox -->
            <div class="form-group row">
                <input type="hidden" class="empresa" value="{{\Auth::user()->empresa_id}}" />
                <select class="form-control evento col mr-3">
                    <option value="">Evento</option>
                </select>
                <select class="form-control setor col mr-3">
                    <option value="">Setor</option>
                </select>
            </div>

        </div>
    </div>
    <div class="card shadow mb-4">
        <div class="card-body">

            <!-- Tabelas -->

            <!-- Funcionários -->
            <strong>Funcionários</strong>
            <table id="funcionarios" class="table table-bordered">
                <thead>
                    <th>Nome</th>
                    <th>CPF</th>
                    <th>RG</th>
                    <th style="width:5%;">Credenciar</th>
                </thead>
                <tbody>
                </tbody>
            </table>

        </div>
    </div>
    <div class="card shadow mb-4">
        <div class="card-body">

            {!! Form::open(['route' => 'site.credenciar.store',  'id' => 'credenciarForm', 'method' => 'post', 'autocomplete' => 'off']) !!}
                
                <!-- Funcionários Cadastrados -->
                <strong>Funcionários Credenciados</strong>
                <table id="credenciados" class="table table-bordered">
                    <thead>
                        <th>Nome</th>
                        <th>CPF</th>
                        <th>RG</th>
                        <th style="width:5%;">Remover</th>
                    </thead>
                    <tbody>
                    </tbody>
                </table>

                <!-- Dados dos Combobox -->
                <input type="hidden"  name="empresa" value="" />
                <input type="hidden"  name="evento"  value="" />
                <input type="hidden"  name="setor"   value="" />
                <input type="hidden" name="lotacao" value="0" class="lotacao"/>


        </div>
    </div>

    {!! Form::submit('Registrar', ['class' => 'btn btn-primary float-right']) !!}
            
    {!! Form::close() !!}

@endsection

@section('js')
    <script src="{{ asset('js/adm/credencial/credenciar.js') }}"></script>
@endsection