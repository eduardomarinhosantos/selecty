@extends('site.template.main')

@section('conteudo')

<!-- Page Heading -->
<p class="mb-4">Lista de todos os Eventos do Credenciador.</p>

<!-- DataTales Example -->
<div class="card shadow mb-4">
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                <thead>
                    <tr>
                        <th>Nome</th>
                        <th>Data</th>
                        <th>Abertura dos Portões</th>
                        <th>Local</th>
                        <th width="5%">Detalhes</th>
                    </tr>
                </thead>
                <tbody>
                    @foreach($registros as $evento)

                        <tr>
                            <td>{{ $evento['nome'] }}</td>
                            <td>{{ date_create_from_format('Y-m-d', $evento['inicio'])->format('d/m/Y') }}</td>
                            <td>{{ date_create_from_format('Y-m-d', $evento['termino'])->format('d/m/Y') }}</td>
                            <td>
                                {{ $evento['local'] }}
                            </td>
                            <td class="text-center">
                                <a href="{{ route('site.evento.show', $evento['id']) }}">
                                    <span class="fa fa-eye"></span>
                                </a>
                            </td>
                        </tr>
                    @endforeach
                </tbody>
            </table>
        </div>
    </div>
</div>

@endsection 