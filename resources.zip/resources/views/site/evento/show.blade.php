@extends('site.template.main')

@section('conteudo')

<!-- DataTales Example -->
<div class="card shadow mb-4">
    <div class="card-header py-3">
        <h6 class="m-0 font-weight-bold text-primary">Dados</h6>
    </div>
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                <tbody>
                    <tr>
                        <td class="titulo_show"> Nome </td>
                        <td>{{ $evento->nome }}</td>
                    </tr>
                    <tr>
                        <td class="titulo_show"> Data </td>
                        <td>{{ date_create_from_format('Y-m-d', $evento->data)->format('d/m/Y') }}</td>
                    </tr>
                    <tr>
                        <td class="titulo_show"> Horário </td>
                        <td>{{ date_create_from_format('H:i:s', $evento->horario)->format('H:i') }}</td>
                    </tr>
                    <tr>
                        <td class="titulo_show"> Local </td>
                        <td>
                            {{ $evento->local->nome }}
                        </td>
                    </tr>
                    <tr>
                        <td class="titulo_show"> Abertura dos Portões </td>
                        <td>{{ date_create_from_format('H:i:s', $evento->abertura)->format('H:i') }}</td>
                    </tr>
                    <tr>
                        <td class="titulo_show"> Inicío do Credenciamento </td>
                        <td>{{ date_create_from_format('Y-m-d H:i:s', $evento->cred_inicio)->format('d/m/Y à\s H:i') }}</td>
                    </tr>
                    <tr>
                        <td class="titulo_show"> Final do Credenciamento </td>
                        <td>{{ date_create_from_format('Y-m-d H:i:s', $evento->cred_fim)->format('d/m/Y à\s H:i') }}</td>
                    </tr>
                    <tr>
                        <td class="titulo_show"> Observação </td>
                        <td>{{ $evento->observacao }}</td>
                    </tr>
                </tbody>
            </table>
        </div>
    </div>
</div>

<div class="card shadow mb-4">
    <div class="card-header py-3">
        <h6 class="m-0 font-weight-bold text-primary">Setores</h6>
    </div>
    <div class="card-body">
        <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
            <thead>
                <th>Setor</th>
                <th>Funcionários Permitidos</th>
                <th>Funcionários Credenciados</th>
            </thead>
            @foreach($evento_empresas as $evento_empresa)
                <tbody>
                    <td>{{ $evento_empresa->setor->nome}}</td>
                    <td>{{ $evento_empresa->lotacao}}</td>
                    <td>
                        @if(count($credenciais) > 0)
                            {{ $credenciais[ $evento_empresa->id]}}
                        @else 
                            0
                        @endif
                    </td>
                </tbody>
            @endforeach
        </table>
    </div>
</div>
@endsection 

@section('js')
    <script src="{{ asset('js/adm/evento/index-show.js') }}"></script>
@endsection