@extends('adm.template.main')

@section('conteudo')
    <meta name="csrf-token" content="{{ csrf_token() }}">  
    <div id="credenciamento"></div>
@endsection


@section('js')
    <script src="{{ asset('/js/app.js') }}"></script>
    <script src="{{ asset('js/adm/credencial/credenciar.js') }}"></script>
@endsection