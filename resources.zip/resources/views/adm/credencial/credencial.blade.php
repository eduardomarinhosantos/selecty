@extends('adm.template.main')

@section('conteudo')
<input id="baseurl" type="hidden" value="{{\URL::to('/')}}" />

    <meta name="csrf-token" content="{{ csrf_token() }}" />
    <div class="card shadow mb-4">
        <div class="card-body">
                
            <!-- Combobox -->
            <div class="form-group row">
                <select name="empresa" class="form-control empresa col mr-3 ml-3">
                    <option value="">Evento</option>
                </select>
                <select name="evento" class="form-control evento col mr-3">
                    <option value="">Período</option>
                </select>
                <select name="setor" class="form-control setor col mr-3">
                    <option value="">Data</option>
                </select>
                <select name="setor" class="form-control setor col mr-3">
                    <option value="">Setor</option>
                </select>
                <select name="setor" class="form-control setor col mr-3">
                    <option value="">Credenciador</option>
                </select>
            </div>
        </div>
    </div>
    <div class="card shadow mb-4">
        <div class="card-body table-responsive">

            <!-- Tabelas -->

            <!-- Funcionários -->
            <strong>Funcionários</strong>
            <table id="funcionarios" class="table table-bordered">
                <thead>
                    <th>Funcionário</th>
                    <th>Empresa</th>
                    <th>Evento</th>
                    <th>Data</th>
                    <th style="width:5%;">Retirado</th>
                    <th style="width:5%;">Impresso</th>
		    <th style="width:5%;">Reverter</th>
                </thead>
                <tbody>
                    <td>Eduardo Bivis</td>
                    <td>TenTicckets</td>
                    <td>Evento Teste</td>
                    <td>10/10/2022</td>
                    <td>
                        <span style="color: green" class="fa fa-check-circle type-retirar"></span>
                    </td>
                    <td>
                        <span style="cursor:pointer; color: red;" class="fa fa-times-circle imprimir type-imprimir"></span>
                    </td>
                    <td>
                        <span style="cursor:pointer; color: blue;" class="fa fa-history reverter"></span>
                    </td>
                </tbody>
            </table>

        </div>
    </div>
 

@endsection

@section('js')
    <script src="{{ asset('js/adm/credencial/credencial.js') }}"></script>
@endsection
