@extends('adm.template.main')

@section('conteudo')

<p class="mb-4">Evento criado em 
    {{ Helper::datahorarioBDtoBR( $evento->created_at ) }}
    <br />e alterado pela última vez em
    {{ Helper::datahorarioBDtoBR( $evento->updated_at ) }}
</p>

@include('adm.flash')

<div class="card shadow mb-4">
    <div class="card-header py-3">
        <h6 class="m-0 mr-1 font-weight-bold text-primary" style="display:inline">Dados</h6>
        <a href="{{ route('evento.edit', $evento->id) }}">
            <span class="fa fa-pencil-alt"></span>
        </a>
        {!! Form::open(['route' => ['evento.destroy', $evento->id], 'method' => 'DELETE', 'class' => 'form-deletar  form-deletar-link']) !!}
            {{ Form::button('<span class="fa fa-trash"></span>', 
                ['type' => 'submit', 'style' => 'color:red', 'class'=>"delete-button"] )  
            }}                        
        {!! Form::close() !!}
        <i class="fas fa-fw fa-clipboard-list pull-left"  style="color: gray"></i>
    </div>

    <!-- DADOS GERAIS -->
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                <tbody>
                    <tr>
                        <td class="titulo_show"> Nome </td>
                        <td>{{ $evento->nome }}</td>
                    </tr>
                   
                    <tr>
                        <td class="titulo_show"> Local </td>
                        <td>
                            <a href="{{ route('local.show', $evento->local->id) }}">
                                {{ $evento->local->nome }}
                            </a>
                        </td>
                    </tr>
                    <tr>
                        <td class="titulo_show"> Observação </td>
                        <td>{{ $evento->observacao }}</td>
                    </tr>
                </tbody>
            </table>
        </div>
    </div>
</div>

<!-- PERIODOS -->
@foreach(
    $evento->evento_periodos 
    as $evento_periodo
)

<div class="card shadow mb-4" style="background-color: #f2fcf2">
    <div class="card-header py-3" style="background-color: #90ee90; color: white;">   
        <h6 class="m-0 font-weight-bold text-primary" style="display:inline;">{{ Helper::getNome( 'periodo', $evento_periodo->periodo->id ) }}</h6>
        <a href="{{ route('evento_periodo.edit', [$evento_periodo->id]) }}">
            <i class="fa fa-pencil-alt"></i>
        </a> 
        {!! Form::open(['route' => ['evento_periodo.destroy', $evento_periodo->id], 'method' => 'DELETE', 'class' => 'form-deletar form-deletar-link']) !!}
            {{ Form::button('<span class="fa fa-trash"></span>', 
                ['type' => 'submit', 'style'  => 'color:red', 'class'=>"delete-button"] )  
            }}                        
        {!! Form::close() !!}
        <i class="fas fa-fw fa-clipboard-list pull-left"  style="color: gray"></i>

        @if(count($evento_periodo->evento_periodo_datas) > 0)
            <i class="fas fa-fw fa-plus float-right text-primary toggle-periodo mt-1"></i>
        @endif
    </div>

    <div class="card-body card-body-periodo" style="display: none">

        <!-- DATAS -->
        @foreach(
            $evento_periodo->evento_periodo_datas 
            as $evento_periodo_data
        )
            <div class="class card mt-3" style="background-color: #f3f2fc">

                <div class="card-header" style="background-color: #add8e6">
                    <h6 class="font-weight-bold"> 
                        <span style="color: #4e73df" class="mt-2">
                            {{ date_create_from_format('Y-m-d', $evento_periodo_data->data)->format('d/m/Y') }}
                        </span>
                        <a href="{{ route('evento_periodo_data.edit', $evento_periodo_data->id) }}">
                            <i class="fa fa-pencil-alt"></i>
                        </a>
                        {!! Form::open(['route' => ['evento_periodo_data.destroy', $evento_periodo_data->id], 'method' => 'DELETE', 'class' => 'form-deletar form-deletar-link']) !!}
                            {{ Form::button('<span class="fa fa-trash"></span>', 
                                ['type' => 'submit', 'style' => 'color:red', 'class'=>"delete-button"] )  
                            }}                        
                        {!! Form::close() !!}
                        <i class="fas fa-fw fa-clipboard-list mr-1 pull-left mt-2" ></i>
                        @if(count($evento_periodo_data->evento_periodo_data_setores) > 0)
                            <i class="fas fa-fw fa-plus float-right text-primary toggle-data mt-2"></i>
                        @endif
                    </h6>
                </div>

                <!-- SETORES -->
                @foreach(
                    $evento_periodo_data->evento_periodo_data_setores 
                    as $evento_periodo_data_setor
                )
                    <div class="card-body card-body-data" style="display: none; @if(!$loop->last) padding-bottom: 5px;) @endif">
                        <div class="card">
                            
                            <div class="card-header py-3">
                                <h6 class="m-0 font-weight-bold" style="display: inline">{{ Helper::getNome( 'setor', $evento_periodo_data_setor->setor->id ) }}</h6>
                                <a href="{{ route('evento_periodo_data_setor.edit', $evento_periodo_data_setor->id) }}">
                                    <i class="fa fa-pencil-alt"></i>
                                </a>
                                {!! Form::open(['route' => ['evento_periodo_data_setor.destroy', $evento_periodo_data_setor->id], 'method' => 'DELETE', 'class' => 'form-deletar form-deletar-link']) !!}
                                    {{ Form::button('<span class="fa fa-trash"></span>', 
                                        ['type' => 'submit', 'style' => 'color:red', 'class'=>"delete-button"] )  
                                    }}                        
                                {!! Form::close() !!}
                                <i class="fas fa-fw fa-clipboard-list mr-1 pull-left"></i>
                                <i class="fas fa-fw fa-plus float-right text-primary toggle-evento-setor mt-1"></i>
                            </div>
                            <div class="card-body card-body-evento-setor table-responsive pb-0" style="display: none">                            
                                    
                                <div>
                                    <strong> Abertura: </strong> 
                                    {{ Helper::horarioBDtoBR( $evento_periodo_data_setor->inicio ) }}
                                </div>
                                <div>
                                    <strong> Credenciamento: </strong> 
                                    {{ Helper::horarioBDtoBR( $evento_periodo_data_setor->inicio_credenciamento ) }}
                                    às 
                                    {{ Helper::horarioBDtoBR( $evento_periodo_data_setor->termino_credenciamento ) }}
                                </div>
                                <div class="mb-2">
                                    <strong> Término: </strong> 
                                    {{ date_create_from_format('H:i:s', $evento_periodo_data_setor->termino)->format('H:i') }}
                                </div>

                                <!-- EMPRESAS -->
                                @foreach(
                                    $evento_periodo_data_setor->evento_periodo_data_setor_empresas
                                    as $evento_periodo_data_setor_empresa
                                ) 
                                    <table class="table table-bordered mt-2" id="dataTable" width="100%" cellspacing="0">
                                        <thead>
                                            <th class="text-center">Empresa Responsável</th>
                                            <th class="text-center">Funcionários Permitidos</th>
                                            <th class="text-center">Funcionários Credenciados</th>
                                            <th style="width: 5%" class="text-center">Detalhes</th>
                                            <th style="width: 5%" class="text-center">Editar</th>
                                            <th style="width: 5%" class="text-center">Credenciar</th>
                                            <th style="width: 5%" class="text-center">Deletar</th>
                                            <th style="width: 5%" class="text-center">Relatório</th>
                                        </thead>
                                        <tbody>
                                            <tr>
                                                <td class="text-center">
                                                    <a href="{{ route('empresa.show', $evento_periodo_data_setor_empresa->empresa->id) }}"> 
                                                        {{ Helper::getNome( 'empresa', $evento_periodo_data_setor_empresa->empresa->id ) }}
                                                    </a>
                                                </td>
                                                <td class="text-center">{{ $evento_periodo_data_setor_empresa->quantidade }}</td>
                                                <td class="text-center">{{ $evento_periodo_data_setor_empresa->credenciais->count() }}</td>
                                                <td class="text-center">
                                                <a href="{{ route('evento_setor_empresa.show', $evento_periodo_data_setor_empresa->id) }}">
                                                    <span class="fa fa-eye"></span>
                                                </a>                                           
                                                <td class="text-center">
                                                    <a href="{{ route('evento_setor_empresa.edit', $evento_periodo_data_setor_empresa->id) }}">
                                                        <i class="fa fa-pencil-alt"></i>
                                                    </a>
                                                </td>
                                                <td class="text-center"><i class="fas fa-fw fa-id-card-alt mr-1"></i></td>
                                                <td class="text-center">
                                                {!! Form::open(['route' => ['evento_setor_empresa.destroy', $evento_periodo_data_setor_empresa->id], 'method' => 'DELETE', 'class' => 'form-deletar']) !!}
                                                    {{ Form::button('<span class="fa fa-trash"></span>', 
                                                        ['type' => 'submit', 'style' => 'color:red', 'class'=>"delete-button"] )  
                                                    }}                        
                                                {!! Form::close() !!}
                                                </td>
                                                <td class="text-center">
                                                    <i class="fas fa-fw fa-clipboard-list pull-left"  style="color: gray"></i>
                                                </td>
                                            </tr>
                                        </tbody>
                                    </table>

                                    <!-- Divisória em linhas ímpar, quando mais de 1 registro -->
                                    @if(count($evento_periodo_data_setor->evento_periodo_data_setor_empresas) > 1 && $loop->iteration % 2 != 0)
                                        <hr class="card-hr" style="display: none;"/>
                                    @endif
                                @endforeach
                            </div>
                        </div>
                    </div>
                @endforeach
            </div>
        @endforeach
    </div>
</div>
@endforeach

@endsection 

@section('js')
    <script src="{{ asset('js/adm/evento/index-show.js') }}"></script>
@endsection