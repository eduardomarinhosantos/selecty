@extends('adm.template.main')

@section('conteudo')

<!-- Page Heading -->
<p class="mb-4">Lista de todas os Eventos cadastrados no sistema.</p>

@include('adm.flash')

<!-- DataTales Example -->
<div class="card shadow mb-4">
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                <thead>
                    <tr>
                        <th>Nome</th>
                        <th>Local</th>
                        <th>Observação</th>
                        <th width="5%">Detalhes</th>
                        <th width="5%">Editar</th>
                        <th width="5%">Excluir</th>
                        <th width="5%">Relatório</th>
                    </tr>
                </thead>
                <tbody>
                    @foreach($registros as $evento)
                        <tr>
                            <td>{{ $evento->nome }}</td>                            
                            <td>
                                <a href="{{ route('local.show', $evento->local->id) }}">
                                    {{ $evento->local->nome }}
                                </a>
                            </td>
                            <td>{{ $evento->observacao }}</td>
                            <td class="text-center">
                                <a href="{{ route('evento.show', $evento->id) }}">
                                    <span class="fa fa-eye"></span>
                                </a>
                            </td>
                            <td class="text-center">
                                <a href="{{ route('evento.edit', $evento->id) }}">
                                    <span class="fa fa-pencil-alt"></span>
                                </a>
                            </td>
                            <td class="text-center">
                                {!! Form::open(['route' => ['evento.destroy', $evento->id], 'method' => 'DELETE', 'class' => 'form-deletar', 'data-modulo' => 'evento']) !!}
                                    {{ Form::button('<span class="fa fa-trash"></span>', 
                                        ['type' => 'submit', 'style' => 'color:red', 'class'=>"delete-button"] )  
                                    }}                        
                                {!! Form::close() !!}
                            </td>
                            <td class="text-center">        
                                <i class="fas fa-fw fa-clipboard-list pull-left"  style="color: gray"></i>
                            </td>
                        </tr>
                    @endforeach
                </tbody>
            </table>
        </div>
    </div>
</div>

@endsection 