<strong class="ml-1">Nome</strong>
<div class='form-group'>
    {!! Form::text('nome', null, ['placeholder'=>'Nome', 'class' => 'form-control']) !!}
</div>

<strong class="ml-1">Local</strong>
<div class='form-group'>
    {!! Form::select('local_id', Helper::getOpcoesSelect('local'), null, ['class' => 'form-control mt-1', 'placeholder' => 'Empresa']) !!}
</div>

<strong class="ml-1">Observação</strong>
<div class='form-group'>
    {!! Form::text('observacao', null, ['placeholder'=>'Observações', 'class' => 'form-control']) !!}
</div>
