@extends('adm.template.main')

@section('css')
    <link rel="stylesheet" type="text/css" href="https://cdn.jsdelivr.net/npm/daterangepicker/daterangepicker.css" />
@endsection

@section('conteudo')

    <!-- Page Heading -->
    <p class="mb-4">Editar Evento</p>

    @include('adm.flash')

    <!-- DataTales Example -->
    {!! Form::model($evento, ['route' => ['evento.update', $evento->id], 'method' => 'put', 'id' => 'editar', 'autocomplete' => 'off']) !!}
        <div class="card shadow mb-4">
            <div class="card-body">
                @include('adm.evento.fields')
            </div>
        </div>        
        {!! Form::submit('Editar', ['class' => 'btn btn-primary float-right']) !!}
    {!! Form::close() !!}

@endsection 

@section('js')
    <script type="text/javascript" src="https://cdn.jsdelivr.net/momentjs/latest/moment.min.js"></script>
    <script type="text/javascript" src="https://cdn.jsdelivr.net/npm/daterangepicker/daterangepicker.min.js"></script>
    <script src="{{ asset('js/adm/evento/create-edit.js') }}"></script>
    <script src="{{ asset('js/adm/evento/edit.js') }}"></script>
@endsection