@extends('adm.template.main')

@section('css')
    <link rel="stylesheet" type="text/css" href="https://cdn.jsdelivr.net/npm/daterangepicker/daterangepicker.css" />
@endsection

@section('conteudo')

<!-- Page Heading -->
<p class="mb-4">Inserir um novo Evento</p>

<input type="hidden" id="periodos" value="{{ $periodos->toJson() }}" />
<input type="hidden" id="locais" value="{{ $locais->toJson() }}" />
<input type="hidden" id="alimentacoes" value="{{ $alimentacoes->toJson() }}" />
<input type="hidden" id="empresas" value="{{ $empresas->toJson() }}" />
<input type="hidden" id="intervalos" value="{{ $intervalos->toJson() }}" />

@include('adm.flash') 

<div id="app"></div>

@endsection 

@section('js')
    <script src="{{ asset('/js/app.js') }}"></script>
    <script src="{{ asset('js/adm/evento/create.js') }}"></script>
@endsection