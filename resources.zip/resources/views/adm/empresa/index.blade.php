@extends('adm.template.main')

@section('conteudo')

<!-- Page Heading -->
<p class="mb-4">Lista de todas os Credenciadores cadastrados no sistema.</p>

@include('adm.flash')

<!-- DataTales Example -->
<div class="card shadow mb-4">
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-bordered display" id="tabelaEmpresas" width="100%" cellspacing="0">
                <thead>
                    <tr>
                        <th>Nome</th>
                        <th>CPF / CNPJ</th>
                        <th>Responsável</th>
                        <th>Email</th>
                        <th width="5%">Detalhes</th>
                        <th width="5%">Editar</th>
                        <th width="5%">Excluir</th>
                    </tr>
                </thead>
                <tbody>
                    @foreach($registros as $empresa)
                        <tr>
                            <td>{{ $empresa-> nome }}</td>
                            <td>{{ $empresa-> cpf_cnpj }}</td>
                            <td>{{ $empresa-> responsavel }}</td>
                            <td>{{ $empresa-> email }}</td>
                            <td class="text-center">
                                <a href="{{ route('empresa.show', $empresa->id) }}">
                                    <span class="fa fa-eye"></span>
                                </a>
                            </td>
                            <td class="text-center">
                                <a href="{{ route('empresa.edit', $empresa->id) }}">
                                    <span class="fa fa-pencil-alt"></span>
                                </a>
                            </td>
                            <td class="text-center">
                                {!! Form::open(['route' => ['empresa.destroy', $empresa->id], 'method' => 'DELETE', 'class' => 'form-deletar', 'data-modulo' => 'empresa']) !!}
                                    {{ Form::button('<span class="fa fa-trash"></span>', 
                                        ['type' => 'submit', 'style' => 'color:red', 'class'=>"delete-button"] )  
                                    }}                        
                                {!! Form::close() !!}
                            </td>
                        </tr>
                    @endforeach
                </tbody>
            </table>
        </div>
    </div>
</div>
@endsection 

@section('js')
    <script src="{{ asset('js/adm/empresa/index-show.js') }}"></script>
@endsection