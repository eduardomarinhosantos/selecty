@extends('adm.template.main')

@section('conteudo')

<!-- Page Heading -->
<p class="mb-4">Editar Credenciador</p>

@include('adm.flash')

<!-- DataTales Example -->
<div class="card shadow mb-4">
    <div class="card-body">
        {!! Form::model($empresa, ['route' => ['empresa.update', $empresa->id], 'method' => 'put', 'id' => 'editar', 'autocomplete' => 'off']) !!}
            @include('adm.empresa.fields')
            <div class="form-group">
                    {!! Form::submit('Editar', ['class' => 'btn btn-primary float-right']) !!}
                </div>
        {!! Form::close() !!}
    </div>
</div>
@endsection 

@section('js')
    <script src="{{ asset('js/adm/empresa/create-edit.js') }}"></script>
@endsection