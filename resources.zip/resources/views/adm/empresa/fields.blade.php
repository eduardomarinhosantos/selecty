<div class='form-group'>
    {!! Form::text('nome', null, ['placeholder'=>'Nome', 'class' => 'form-control']) !!}
</div>
<div class='form-group'>
    {!! Form::text('cpf_cnpj', null, ['placeholder'=>'CPF / CNPJ', 'class' => 'form-control']) !!}
</div>
<div class='form-group'>
    {!! Form::text('responsavel', null, ['placeholder'=>'Responsável', 'class' => 'form-control']) !!}
</div>
<div class='form-group'>
    {!! Form::text('email', null, ['placeholder'=>'Email', 'class' => 'form-control']) !!}
</div>
<div class="form-group">
    {!! Form::password('senha', ['placeholder'=>'Senha - Preencha apenas se quiser alterar', 'class' => 'form-control', 'maxlength' => 8]) !!}
</div>
