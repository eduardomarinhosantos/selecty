@extends('adm.template.main')

@section('conteudo')
<input id="baseurl" type="hidden" value="{{\URL::to('/')}}" />

<!-- Page Heading -->
<p class="mb-4">
    @switch($relatorio)
        @case(1)
            Relatório de Credenciamento por Evento 
            @break;
    @endswitch
</p>

<div class="card shadow mb-4">
    <div class="card-body">

        @switch($relatorio)
            @case(1)
                @include('adm.relatorio.relatorios.1', ['dados' => $dados])
                @break;
        @endswitch

    </div>
</div>


@endsection

@section('js')
    <script src="{{ asset('js/adm/relatorio/'.$relatorio.'.js') }}"></script>
@endsection
