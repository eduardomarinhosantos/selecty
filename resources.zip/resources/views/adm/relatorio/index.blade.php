@extends('adm.template.main')

@section('conteudo')
<!-- Page Heading -->
<p class="mb-4">Sessão de Relatórios do Sistema.</p>

<div class="card shadow mb-4">
    <div class="card-body">
        <ul class="mb-0" style="padding-left: 20px !important;">
            <li>
                <a href="{{ route('relatorio.show', ['id' => 1]) }}" style="text-decoration: none; color: #858796;">
                    Relatório de Credenciamento por Evento 
                </a>
            </li>            
        </ul>
    </div>
</div>

@endsection