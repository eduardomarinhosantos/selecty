<form>
    <div class="loading" style="display:none"></div>
    <div class="form-group">
        
        <select id="evento" class="form-control col-md-6" style="display: inline;">
            <option value="" selected disabled>Evento</option>
            @foreach( $dados['eventos'] as $evento)
                <option value="{{ $evento->id }}">{{ $evento->nome }}</option>
            @endforeach
        </select>
        <span class="offset-md-4" style="padding-left: 40px;">
            <a id="download" target="_blank" style="display: none;" class="pull-right btn btn-primary">Baixar em PDF</a>
        </span>
    </div>

    <table class="table" style="">
        <thead>
            <th>Período</th>
            <th>Data</th>
            <th>Setor</th>
            <th>Credenciador</th>
            <th>Credenciado</th>
            <th>Função</th>
        </thead>
        <tbody></tbody>
    </table>
</form>

