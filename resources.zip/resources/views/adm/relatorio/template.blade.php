<style>
    table{
        width: 100%;
    }
    td{
        padding: 5px;
        border: 1px solid #d3d3d3;
    }
    .thead{
        background-color: #d3d3d3;
    }
</style>
{!! $dados !!}