@extends('adm.template.main')

@section('conteudo')

<!-- Page Heading -->
<p class="mb-4"></p>

@include('adm.flash')

<!-- DataTales Example -->
<div class="card shadow mb-4">
    <div class="card-header"><h6 class="m-0 mr-1 font-weight-bold text-primary">Editar Data do Evento</h6></div>
    <div class="card-body">

        <div class="alert alert-info col-md-10">
            Ao remover um Setor da Data você perderá todas as credenciais feitas até o momento nesse Setor.
        </div>

        {!! Form::open(['route' => ['evento_periodo_data.update', $evento_periodo_data->id], 'method' => 'put', 'id' => 'criar', 'autocomplete' => 'off']) !!}
        
            <div class="row" style="margin-left: 1px;">

                @foreach(
                    $evento_periodo_data->evento_periodo_data_setores 
                    as $evento_periodo_data_setor
                )    
                    <div class="card col-md-5 mb-3 mr-3" style="padding: 0px !important;">
                        <div class="card-header py-3" >
                            <input type="hidden" value="{{ $evento_periodo_data_setor->id }}">
                            <h6 class="m-0 font-weight-bold" style="display: inline">{{ $evento_periodo_data_setor->setor->nome }}</h6>
                            <i class="fas fa-trash float-right text-primary mt-1"></i>
                        </div>    
                        <div class="card-body">
                            <div>
                                <strong> Abertura: </strong> 
                                {{ Helper::horarioBDtoBR( $evento_periodo_data_setor->inicio ) }}
                            </div>
                            <div>
                                <strong> Credenciamento: </strong> 
                                {{ Helper::horarioBDtoBR( $evento_periodo_data_setor->inicio_credenciamento ) }}
                                às 
                                {{ Helper::horarioBDtoBR( $evento_periodo_data_setor->termino_credenciamento ) }}
                            </div>
                            <div class="mb-2">
                                <strong> Término: </strong> 
                                {{ date_create_from_format('H:i:s', $evento_periodo_data_setor->termino)->format('H:i') }}
                            </div>
                        </div>  
                    </div>   
                @endforeach
            </div>
            <div class="mb-2 ml-2 mt-5">
                <span class="fa fa-puzzle-piece mr-2"></span>
                <strong class="mr-2">Adicionar Setor</strong>
                <i class="fas fa-fw fa-plus text-primary toggle-evento-setor mt-1" style="color: green !important"></i>
            </div>

            <div id="novos-setores-container" class="row" style="margin-left: 1px">
                <div class="card col-md-5 setor-modelo mr-3 mb-3" style="display: none">
                    <div class="card-body">
                        <div class="mb-4">
                            <i class="fas fa-times float-right text-primary mt-1"></i>
                        </div>
                        <strong style="display: block">Setor</strong>
                        <select class="form-control col-md-11" name="setor[]">
                            @foreach(
                                $evento_periodo_data->evento_periodo->evento->local->setores 
                                as $setor
                            )
                                <option value="{{ $setor->id }}">{{ $setor->nome }}</option>
                            @endforeach
                        </select>

                        <strong style="display: block" class="mt-3">Abertura - Término</strong>
                        <input 
                            name="inicio[]"
                            type="text" 
                            class="form-control col-md-5 horario" 
                            style="display: inline" /> às
                        
                        <input 
                            name="termino[]"
                            type="text" 
                            class="form-control col-md-5 horario" 
                            style="display: inline" />

                        <strong style="display: block" class="mt-3">Credenciamento</strong>
                        <input 
                            name="inicio_credenciamento[]"
                            type="text" 
                            class="form-control col-md-5 horario" 
                            style="display: inline" /> às 
                        <input 
                            name="termino_credenciamento[]"
                            type="text" 
                            class="form-control col-md-5 horario" 
                            style="display: inline" />

                    </div>
                </div>
            </div>        

            <div class="form-group">
                {!! Form::submit('Editar', ['class' => 'btn btn-primary float-right ml-2']) !!}
                <a 
                    class="btn btn-success float-right" 
                    href="{{ 
                        route(
                            'evento.show', 
                            $evento_periodo_data->evento_periodo->evento->id
                            ) 
                        }}">
                    Voltar <i class="fa fa-history"></i>
                </a>
            </div>
        {!! Form::close() !!}
        
    </div>
</div>
@endsection 

@section('js')
    <script src="{{ asset('js/adm/evento_periodo_data/edit.js') }}"></script>
@endsection