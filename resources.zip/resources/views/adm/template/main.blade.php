
{{--  Variáveis --}}
@php
    $modulo = explode('.', Route::current()->getName())[0];
    $view   = explode('.', Route::current()->getName())[1];
    if(isset(explode('/', Request::url())[4])) $id = explode('/', Request::url())[4]; 
@endphp
<!DOCTYPE html>
<html lang="en">

    <head>

        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
        <meta name="description" content="">
        <meta name="author" content="">

        <title>TenTickets System</title>

        <!-- Estilos Obrigatórios -->
        <link href="{{ asset('css/libs/bootstrap-datepicker.min.css') }}" rel="stylesheet">
        <link href="{{ asset('css/fontawesome-free/css/all.min.css') }}" rel="stylesheet" type="text/css">
        <link href="{{ asset('css/sb-admin-2.css') }}" rel="stylesheet">
        <link href="{{ asset('css/custom.css') }}" rel="stylesheet">
        <link href="{{ asset('css/libs/sweetalert2.min.css') }}" rel="stylesheet">

        <!-- Estilos por View-->
        @if($view == 'index' || $view == 'show')
            <link href="{{ asset('css/libs/dataTables.bootstrap4.min.css') }}" rel="stylesheet">
        @endif

        @yield('css')    

    </head>

    <body id="page-top">

        <div id="wrapper">

            <!-- Menu -->
            @include('adm.template.menu')

            <div id="content-wrapper" class="d-flex flex-column">

                <div id="content">

                    <!-- Topbar -->
                    @include('adm.template.topbar')

                    <!-- Conteúdo -->
                    <div class="container-fluid">

                        <!-- Cabeçalho -->
                        <div class="d-sm-flex align-items-center justify-content-between mb-4">
                            <h1 class="h3 mb-0 text-gray-800">   
                                
                            @switch($modulo)

                                @case('evento_periodo')
                                        <i class="fas fa-fw fa-calendar mr-1"></i>
                                        
                                        {{ $evento_periodo->evento->nome }}                               
                                        @break

                                @case('evento_periodo_data')
                                    <i class="fas fa-fw fa-calendar mr-1"></i>
                                    
                                    {{                                             
                                        $evento_periodo_data
                                            ->evento_periodo
                                            ->evento->nome
                                    }} 
                                    <strong style="font-size: 14px">

                                        ({{ Helper::dataBDtoBR( 
                                            $evento_periodo_data->data 
                                        )}})
                                    </strong>                                
                                    @break

                                @case('evento_periodo_data_setor')
                                <i class="fas fa-fw fa-calendar mr-1"></i>
                                
                                {{                                             
                                    $evento_periodo_data_setor
                                        ->evento_periodo_data
                                        ->evento_periodo
                                        ->evento->nome
                                }} 
                                <strong style="font-size: 14px">
                                    {{ 
                                        $evento_periodo_data_setor
                                            ->setor->nome 
                                    }} 
                                    ({{ Helper::dataBDtoBR( 
                                        $evento_periodo_data_setor
                                            ->evento_periodo_data->data 
                                    )}})
                                </strong>                                
                                @break

                                @case('evento_setor_empresa')
                                    <i class="fas fa-fw fa-calendar mr-1"></i>
                                    
                                    {{ 
                                        
                                        $evento_periodo_data_setor_empresa
                                            ->evento_periodo_data_setor
                                            ->evento_periodo_data
                                            ->evento_periodo
                                            ->evento->nome
                                    }} 
                                    <strong style="font-size: 14px">
                                        {{ 
                                            $evento_periodo_data_setor_empresa
                                                ->evento_periodo_data_setor
                                                ->setor->nome 
                                        }} 
                                        ({{ Helper::dataBDtoBR( 
                                            $evento_periodo_data_setor_empresa
                                                ->evento_periodo_data_setor
                                                ->evento_periodo_data->data 
                                        )}})
                                    </strong>                                
                                    @break


                                @default
                                                                        
                                    @switch($modulo)

                                        @case('empresa') 
                                            <i class="fas fa-fw fa-building mr-1"></i>
                                            @if($view == 'index') Credenciadores
                                            @elseif($view == 'create') {{ 'Novo Registro' }}
                                            @else {{ $empresa->nome }}
                                            @endif
                                            @break

                                        @case('funcionario') 
                                            <i class="fas fa-fw fa-users mr-1"></i>
                                            @if($view == 'index') Credenciados
                                            @elseif($view == 'create') {{ 'Novo Registro' }}
                                            @else {{ $funcionario->nome }}
                                            @endif
                                            @break

                                        @case('local') 
                                            <i class="fas fa-fw fa-map-marker-alt mr-1"></i>
                                            @if($view == 'index') Locais
                                            @elseif($view == 'create') {{ 'Novo Registro' }}
                                            @else {{ $local->nome }}
                                            @endif 
                                            @break

                                        @case('evento') 
                                            <i class="fas fa-fw fa-calendar mr-1"></i>
                                            @if($view == 'index') Eventos
                                            @elseif($view == 'create') {{ 'Novo Registro' }}
                                            @else {{ $evento->nome }}
                                            @endif 
                                            @break
                                        
                                        @case('credenciar') 
                                            <i class="fas fa-fw fa-id-card-alt mr-1 mb-3"></i>
                                            Credenciar 
                                            @break
                                            
                                        @case('credencial') 
                                            <i class="fas fa-fw fa-id-card mr-1 mb-3"></i>
                                            Credenciais 
                                            @break

                                        @case('relatorio')
                                            <i class="fas fa-fw fa-chart-area mr-1"></i>
                                            Relatórios 
                                            @break
                                            
                                    @endswitch                                       
                            @endswitch
                                
                            </h1>
                            @if( 
                                $modulo != 'credenciar' && 
                                $modulo != 'credencial' &&
                                $modulo != 'relatorio'  &&
                                $modulo != 'evento_periodo' &&
                                $modulo != 'evento_periodo_data' &&
                                $modulo != 'evento_periodo_data_setor' &&
                                $modulo != 'evento_setor_empresa'
                                
                            )
                                <div class="float-right">
                                    
                                    @if( $view == 'show' || $view == 'edit' || $view == 'create')
                                        <a href="{{ route($modulo.'.index') }}" class="d-none d-sm-inline-block btn btn-sm btn-warning shadow-sm">
                                            <i class="fas fa-list fa-sm text-white-50"></i> Listar Registros
                                        </a>
                                    @endif
                                    
                                    @if( $view == 'show')
                                        <a href="{{ route($modulo.'.edit', $id) }}" class="d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm">
                                            <i class="fas fa-pencil-alt fa-sm text-white-50"></i> Editar Registro
                                        </a>
                                    @endif
                                    
                                    @if( $view == 'index' || $view == 'edit' || $view == 'show')
                                        <a href="{{ route($modulo.'.create') }}" class="d-none d-sm-inline-block btn btn-sm btn-success shadow-sm">
                                            <i class="fas fa-plus fa-sm text-white-50"></i> Novo Registro
                                        </a>
                                    @endif
                                </div>
                            @endif
                        </div>
                        
                        @yield('conteudo')

                    </div>

                </div>

                <!-- Footer -->
                <footer class="sticky-footer bg-white">
                    <div class="container my-auto">
                    <div class="copyright text-center my-auto">
                        <span>Copyright &copy; TenTickets 2019</span>
                    </div>
                    </div>
                </footer>

            </div>

        </div>

        <!-- Scripts Obrigatórios -->
        <script src="{{ asset('js/libs/jquery-1.11.2.min.js') }}"></script>
        <script src="{{ asset('js/libs/bootstrap.bundle.min.js') }}"></script>
        <script src="{{ asset('js/libs/sb-admin-2.min.js') }}"></script>
        <script src="{{ asset('js/libs/sweetalert2.min.js') }}"></script>
        <script src="{{ asset('js/libs/bootstrap-datepicker.min.js') }}"></script>
        <script src="{{ asset('js/libs/bootstrap-datepicker-portugues.min.js') }}"></script>

        <!-- Scripts por View-->
        @if($view == 'index' || $view == 'show')
            <script src="{{ asset('js/libs/jquery.dataTables.min.js') }}"></script>
            <script src="{{ asset('js/libs/dataTables.bootstrap4.min.js') }}"></script>
            <script src="{{ asset('js/adm/template/index-show.js') }}"></script>
         @endif
        
        @if($view == 'edit' || $view == 'create' || $modulo == 'credenciar')
            <script src="{{ asset('js/libs/jquery.mask.min.js') }}"></script>
            <script src="{{ asset('js/libs/jquery-validate.min.js') }}"></script>
            <script src="{{ asset('js/libs/additional-methods.js') }}"></script>
        @endif

        @if($view == 'create' && $modulo == 'evento')
            <script src="https://cdn.jsdelivr.net/npm/vue@2.6.0"></script>
        @endif

        @yield('js')
    </body>
</html>