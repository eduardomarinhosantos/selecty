<ul class="navbar-nav bg-gradient-primary sidebar sidebar-dark accordion" id="accordionSidebar">

    
    <hr class="sidebar-divider">

    <div class="sidebar-heading">
        Credenciamento
    </div>

    <li class="nav-item">
        <a class="nav-link" href="{{ route('credencial.index') }}">
            <i class="fas fa-fw fa-id-card"></i>
            <span>Credenciais</span>
        </a>
    </li>

    <li class="nav-item">
        <a class="nav-link" href="{{ route('credenciar.index') }}">
            <i class="fas fa-fw fa-id-card-alt"></i>
            <span>Credenciar</span>
        </a>
    </li>

    <hr class="sidebar-divider">

    <div class="sidebar-heading">
        Entidades
    </div>

    <li class="nav-item">
        <a class="nav-link" href="{{ route('empresa.index') }}">
            <i class="fas fa-fw fa-building"></i>
            <span>Credenciadores</span>
        </a>
    </li>

    <li class="nav-item">
        <a class="nav-link" href="{{ route('funcionario.index') }}">
            <i class="fas fa-fw fa-users"></i>
            <span>Credenciados</span>
        </a>
    </li>

    <li class="nav-item">
        <a class="nav-link" href="{{ route('local.index') }}">
            <i class="fas fa-fw fa-map-marker-alt"></i>
            <span>Locais</span>
        </a>
    </li>

    <li class="nav-item">
        <a class="nav-link" href="{{ route('evento.index') }}">
            <i class="fas fa-fw fa-calendar"></i>
            <span>Eventos</span>
        </a>
    </li>

    <hr class="sidebar-divider">

    <div class="sidebar-heading">
        Ferramentas
    </div>

    <li class="nav-item">
        <a class="nav-link" href="{{ route('relatorio.index') }}">
            <i class="fas fa-fw fa-chart-area"></i>
            <span>Relatórios</span>
        </a>
    </li>

    <hr class="sidebar-divider d-none d-md-block">

    <div class="text-center d-none d-md-inline">
        <button class="rounded-circle border-0" id="sidebarToggle"></button>
    </div>

</ul>