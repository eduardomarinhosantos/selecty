@extends('adm.template.main')

@section('conteudo')

<!-- Page Heading -->
<p class="mb-4"></p>

@include('adm.flash')

<!-- DataTales Example -->
<div class="card shadow mb-4">
    <div class="card-header"><h6 class="m-0 mr-1 font-weight-bold text-primary">Editar Período do Evento</h6></div>
    <div class="card-body">
        <div class="alert alert-info">
            Ao remover uma Data do intervalo você perderá todas as credenciais feitas até o momento nessa Data.
            <br />
        </div>

        {!! Form::open(['route' => ['evento_periodo.update', $evento_periodo->id], 'method' => 'put', 'id' => 'criar', 'autocomplete' => 'off']) !!}
            <strong>Início - Término</label>
            <div class='form-group'>
                {!! Form::text('inicio', Helper::dataBDtoBR($evento_periodo->evento_periodo_datas->min('data')), ['class' => 'form-control data col-md-2', 'style'=>'display: inline', 'readonly' => 'readonly']) !!}
                {!! Form::text('termino', Helper::dataBDtoBR($evento_periodo->evento_periodo_datas->max('data')), ['class' => 'form-control data col-md-2', 'style'=>'display: inline', 'readonly' => 'readonly']) !!}
            </div>
            <div class="form-group">
                {!! Form::submit('Registrar', ['class' => 'btn btn-primary float-right ml-2']) !!}
                <a 
                    class="btn btn-success float-right" 
                    href="{{ route('evento.show', $evento_periodo->evento->id) }}">
                    Voltar <i class="fa fa-history"></i>
                </a>
            </div>
        {!! Form::close() !!}


    </div>
</div>
@endsection 

@section('js')
    <script src="{{ asset('js/adm/evento_periodo/edit.js') }}"></script>
@endsection