@extends('adm.template.main')

@section('conteudo')

<!-- Page Heading -->
<p class="mb-4">Local criado em 
    {{ Helper::datahorarioBDtoBR( $local->created_at ) }}
    <br />e alterado pela última vez em
    {{ Helper::datahorarioBDtoBR( $local->updated_at ) }}
    
    @include('adm.flash')
</p>


<!-- DataTales Example -->
<div class="card shadow mb-4">
    <div class="card-header py-3">
        <h6 class="m-0 font-weight-bold text-primary">Dados</h6>
    </div>
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                <tbody>
                    <tr>
                        <td class="titulo_show"> Nome </td>
                        <td>{{ $local->nome }}</td>
                    </tr>
                    <tr>
                        <td class="titulo_show"> Descrição </td>
                        <td>{{ $local->descricao }}</td>
                    </tr>
                    <tr>
                        <td class="titulo_show"> Endereço </td>
                        <td>{{ $local->endereco }}</td>
                    </tr>
                    <tr>
                        <td class="titulo_show">Editar</td>
                        <td>
                            <a href="{{ route('local.edit', $local->id) }}">
                                <span class="fa fa-pencil-alt"></span>
                            </a>
                        </td>
                    </tr>
                    <tr>
                        <td class="titulo_show">Deletar</td>
                        <td>
                            {!! Form::open(['route' => ['local.destroy', $local->id], 'method' => 'DELETE', 'class' => 'form-deletar', 'data-modulo' => 'local']) !!}
                                {{ Form::button('<span class="fa fa-trash"></span>', 
                                    ['type' => 'submit', 'style' => 'color:red', 'class'=>"delete-button"] )  
                                }}                        
                            {!! Form::close() !!}
                        </td>
                    </tr>
                </tbody>
            </table>
        </div>
    </div>
</div>

<div class="card shadow mb-4">

    <div class="card-header py-3">
        <h6 class="m-0 font-weight-bold text-primary">Setores</h6>
    </div>
    <div class="card-body">
            
        <div class="table-responsive">
            <table class="table table-bordered display" id="dataTable" width="100%" cellspacing="0">
                <thead>
                    <tr>
                        <th>Nome</th>
                        <th>Descrição</th>
                        <th style="width: 5%">Deletar</th>
                    </tr>
                </thead>
                </tbody>
                    @foreach($local->setores as $setor)
                        <tr>
                            <td>{{ $setor->nome }}</td>
                            <td>{{ $setor->descricao }}</td>
                            <td class="text-center">
                                {!! Form::open(['url' => ['/setor', $setor->id], 'method' => 'DELETE', 'class'=>'form-deletar', 'data-modulo' => 'setor']) !!}
                                    {{ Form::button('<span class="fa fa-trash"></span>', 
                                        ['type' => 'submit', 'style' => 'color:red', 'class'=>"delete-button"] )  
                                    }}                        
                                {!! Form::close() !!}                            
                            </td>
                        </tr>
                    @endforeach
                </tbody>
            </table>
        </div>
    </div>
</div>

<!-- Eventos -->
<div class="card shadow mb-4">
    <div class="card-header py-3">
        <h6 class="m-0 font-weight-bold text-primary">Eventos</h6>
    </div>
    <div class="card-body">
            
        <div class="table-responsive">
            <table class="table table-bordered display" width="100%" cellspacing="0">
                <thead>
                    <tr>
                        <th>Nome</th>
                        <th width="5%">Detalhes</th>
                    </tr>
                </thead>
                <tbody>
                    @foreach($eventos as $evento)
                        <td>
                            <a href="{{ route('evento.show', $evento->id) }}">
                                {{ $evento->nome }}
                            </a>
                        </td><td class="text-center">
                            <a href="{{ route('evento.show', $evento->id) }}">
                                <span class="fa fa-eye"></span>
                            </a>
                        </td>
                    @endforeach
                </tbody>
            </table>
        </div>
    </div>
</div>
@endsection 

@section('js')
    <script src="{{ asset('js/adm/local/index-show.js') }}"></script>
@endsection