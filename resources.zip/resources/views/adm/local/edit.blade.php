@extends('adm.template.main')

@section('conteudo')

<!-- Page Heading -->
<p class="mb-4">Editar Local</p>

@include('adm.flash')

<!-- DataTales Example -->
{!! Form::model($local, ['route' => ['local.update', $local->id], 'method' => 'put', 'id' => 'editar', 'autocomplete' => 'off']) !!}
    <div class="card shadow mb-4">
        <div class="card-body">
            @include('adm.local.fields')

            <!-- Setores -->
            <div class="mb-2">
                <span class="fa fa-puzzle-piece mr-2"></span>Setores 
            </div>
            @foreach($local->setores as $setor)
                <div class="block form-group mb-0">
                    <span class="input">
                        <input name="ids_edit[]" type="hidden" class="hidden" value="{{ $setor->id }}" />
                        <input 
                            type="text" 
                            name="nomes_edit[]" 
                            class="form-control mb-2 col-md-3 form-control-inline" 
                            placeholder="Nome"
                            value="{{ $setor->nome }}" />
                        <input 
                            type="text" 
                            name="descricoes_edit[]" 
                            class="form-control mb-2 col-md-3 form-control-inline" 
                            placeholder="Descrição"
                            value="{{ $setor->descricao }}" />
                        
                    </span>
                </div>
            @endforeach

            <hr />

            <div class="mb-2 ml-2">
                <span class="fa fa-puzzle-piece mr-2"></span>
                <strong>Adicionar Setores</strong>
            </div>
        </div>
    </div>

    <!-- Add Setores -->
    <div id="block-container" class="row">
        <div class="block-model mb-0 col-md-3">

            <div class="card shadow mb-4">
                <div class="card-body">

                    <!-- Add Setores -->
                    @include('adm.local.addsetor')   

                </div>
            </div>

        </div>
    </div>
    
    <div class="form-group">
        {!! Form::submit('Editar', ['class' => 'btn btn-primary float-right']) !!}
    </div>
    {!! Form::close() !!}
@endsection 

@section('js')
    <script src="{{ asset('js/adm/local/create-edit.js') }}"></script>
@endsection