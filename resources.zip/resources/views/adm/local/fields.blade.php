<div class='form-group'>
    {!! Form::text('nome', null, ['placeholder'=>'Nome', 'class' => 'form-control']) !!}
</div>
<div class='form-group'>
    {!! Form::text('descricao', null, ['placeholder'=>'Descrição', 'class' => 'form-control']) !!}
</div>
<div class='form-group'>
    {!! Form::text('endereco', null, ['placeholder'=>'Endereço', 'class' => 'form-control']) !!}
</div>

