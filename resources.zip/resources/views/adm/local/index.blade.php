@extends('adm.template.main')

@section('conteudo')

<!-- Page Heading -->
<p class="mb-4">Lista de todas os Locais cadastrados no sistema.</p>

@include('adm.flash')

<!-- DataTales Example -->
<div class="card shadow mb-4">
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-bordered display" id="dataTable" width="100%" cellspacing="0">
                <thead>
                    <tr>
                        <th>Nome</th>
                        <th>Descrição</th>
                        <th>Endereço</th>
                        <th width="5%">Detalhes</th>
                        <th width="5%">Editar</th>
                        <th width="5%">Excluir</th>
                    </tr>
                </thead>
                <tbody>
                    @foreach($registros as $local)
                        <tr>
                            <td>{{ $local-> nome }}</td>
                            <td>{{ $local-> descricao }}</td>
                            <td>{{ $local-> endereco }}</td>
                            <td class="text-center">
                                <a href="{{ route('local.show', $local->id) }}">
                                    <span class="fa fa-eye"></span>
                                </a>
                            </td>
                            <td class="text-center">
                                <a href="{{ route('local.edit', $local->id) }}">
                                    <span class="fa fa-pencil-alt"></span>
                                </a>
                            </td>
                            <td class="text-center">
                                {!! Form::open(['route' => ['local.destroy', $local->id], 'method' => 'DELETE', 'class' => 'form-deletar', 'data-modulo' => 'local']) !!}
                                    {{ Form::button('<span class="fa fa-trash"></span>', 
                                        ['type' => 'submit', 'style' => 'color:red', 'class'=>"delete-button"] )  
                                    }}                        
                                {!! Form::close() !!}
                            </td>
                        </tr>
                    @endforeach
                </tbody>
            </table>
        </div>
    </div>
</div>
@endsection 

@section('js')
    <script src="{{ asset('js/adm/local/index-show.js') }}"></script>
@endsection