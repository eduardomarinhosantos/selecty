
<table>
    <tbody>
        <tr>
            <td>
                <input 
                    type="text" 
                    name="nomes[]" 
                    class="form-control mb-2 col-md-12 input-setor nomes"
                    placeholder="Nome" />
            </td>
        </tr>
        <tr>
            <td>
                <input 
                    type="text" 
                    name="descricoes[]" 
                    class="form-control mb-2 col-md-12 input-setor" 
                    placeholder="Descrição" />
            </td>
        </tr>
        <tr>
            <td colspan="2">
                <a style="cursor: pointer; color:white; padding-top: -5" class="add btn btn-block btn-success mt-2">
                    Adicionar <span class="fa fa-plus-circle ml-2"></span>
                </a>
            </td>
            <td colspan="2">
                <a style="display: none; cursor: pointer; color:white; padding-top: -5" class="remove btn btn-block btn-danger mt-2">
                    Remover <span class="fa fa-trash ml-2"></span>
                </a>
            </td>
        </tr>
    </tbody>
</table>
 