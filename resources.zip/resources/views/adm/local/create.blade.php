@extends('adm.template.main')

@section('conteudo')

<!-- Page Heading -->
<p class="mb-4">Inserir um novo Local</p>

@include('adm.flash')

<!-- DataTales Example -->
{!! Form::open(['route' => 'local.store', 'method' => 'post', 'id' => 'criar', 'autocomplete' => 'off']) !!}
<div class="card shadow mb-4">
    <div class="card-body">
        @include('adm.local.fields')
    </div>
</div>

<div class="mb-2 ml-2">
    <span class="fa fa-puzzle-piece mr-2"></span>
    <strong>Adicionar Setores</strong>
</div>

<div id="block-container" class="row">
    <div class="block-model mb-0 col-md-3">

        <div class="card shadow mb-4">
            <div class="card-body">

                <!-- Add Setores -->
                @include('adm.local.addsetor')   

            </div>
        </div>

    </div>
</div>

<div class="form-group">
    {!! Form::submit('Registrar', ['class' => 'btn btn-primary float-right']) !!}
</div>

{!! Form::close() !!}



@endsection 

@section('js')
    <script src="{{ asset('js/adm/local/create-edit.js') }}"></script>
@endsection