@extends('adm.template.main')

@section('css')
    <link rel="stylesheet" type="text/css" href="https://cdn.jsdelivr.net/npm/daterangepicker/daterangepicker.css" />
@endsection

@section('conteudo')

    <!-- Page Heading -->
    <p class="mb-4">Editar Evento</p>

    <div class="alert alert-info">
        Ao alterar o <strong>Credenciador</strong> você perderá todas as credenciais feitas até o momento.
        <br />
        O <strong>Quantidade Máxima de Credenciados Permitida</strong> não pode ser inferior ao total já credenciado.
    </div>

    @include('adm.flash')

    <!-- DataTales Example -->
    {!! Form::model($evento_periodo_data_setor_empresa, ['route' => ['evento_setor_empresa.update', $evento_periodo_data_setor_empresa->id], 'method' => 'put', 'id' => 'editar', 'autocomplete' => 'off']) !!}
        <div class="card shadow mb-4">
            <div class="card-body">
                @include('adm.evento_periodo_data_setor_empresa.fields')
            </div>
        </div>        
        {!! Form::submit('Editar', ['class' => 'btn btn-primary float-right']) !!}
    {!! Form::close() !!}

@endsection 

@section('js')
    <script type="text/javascript" src="https://cdn.jsdelivr.net/momentjs/latest/moment.min.js"></script>
    <script type="text/javascript" src="https://cdn.jsdelivr.net/npm/daterangepicker/daterangepicker.min.js"></script>
@endsection