@extends('adm.template.main')

@section('conteudo')

<!-- Page Heading -->
<p class="mb-4">Registro criado em 
    {{ Helper::datahorarioBDtoBR($evento_periodo_data_setor_empresa->created_at) }} 
    e alterado pela última vez em
    {{ Helper::datahorarioBDtoBR($evento_periodo_data_setor_empresa->updated_at) }}
</p>

<!-- DataTales Example -->
<div class="card shadow mb-4">
    <div class="card-header py-3">
        <h6 class="m-0 font-weight-bold text-primary">Dados Gerais</h6>
    </div>
    <div class="card-body">
        
        <div class="table-responsive">
            <table class="table table-bordered" width="100%" cellspacing="0">
                <tr>
                    <td class="titulo_show">Evento</td>
                    <td>
                        <a href="{{ 
                            route(
                                'evento.show', 
                                $evento_periodo_data_setor_empresa
                                    ->evento_periodo_data_setor
                                    ->evento_periodo_data
                                    ->evento_periodo
                                    ->evento->id
                            ) 
                        }}">
                            {{ 
                                $evento_periodo_data_setor_empresa
                                    ->evento_periodo_data_setor
                                    ->evento_periodo_data
                                    ->evento_periodo
                                    ->evento->nome
                             }}
                        </a>
                    </td>                        
                </tr>
                <tr>
                    <td class="titulo_show">Empresa</td>
                    <td>
                        <a href="{{ 
                            route(
                                'empresa.show', 
                                $evento_periodo_data_setor_empresa->empresa->id
                            ) 
                        }}">
                            {{ 
                                $evento_periodo_data_setor_empresa
                                    ->empresa
                                    ->nome 
                            }}
                        </a>
                    </td>                        
                </tr>
                <tr>
                    <td class="titulo_show">Local</td>
                    <td>
                        <a href="{{ 
                            route(
                                'local.show', 
                                $evento_periodo_data_setor_empresa
                                    ->evento_periodo_data_setor
                                    ->evento_periodo_data
                                    ->evento_periodo
                                    ->evento->id
                            ) 
                        }}">
                            {{ 
                                $evento_periodo_data_setor_empresa
                                    ->evento_periodo_data_setor
                                    ->evento_periodo_data
                                    ->evento_periodo
                                    ->evento->local->nome 
                            }}
                        </a>
                    </td>                        
                </tr>
                <tr>
                    <td class="titulo_show">Setor</td>
                    <td>{{ 
                            $evento_periodo_data_setor_empresa
                                ->evento_periodo_data_setor
                                ->setor->nome 
                        }}
                    </td>
                </tr>
                <tr>
                    <td class="titulo_show">Período</td>
                    <td>
                        {{ 
                            $evento_periodo_data_setor_empresa
                                ->evento_periodo_data_setor
                                ->evento_periodo_data
                                ->evento_periodo
                                ->periodo->nome 
                        }}
                    </td>
                </tr>
                <tr>
                    <td class="titulo_show">Data</td>
                    <td>{{ 
                            Helper::dataBDtoBR( 
                                $evento_periodo_data_setor_empresa
                                    ->evento_periodo_data_setor
                                    ->evento_periodo_data->data 
                            ) 
                        }}
                    </td>
                </tr>
                <tr>
                    <td class="titulo_show">Funcionários Permitidos</td>
                    <td>
                        {{ $evento_periodo_data_setor_empresa->quantidade }}
                    </td>
                </tr>
                <tr>
                    <td class="titulo_show">Funcionários Credenciados</td>   
                    <td>{{ $evento_periodo_data_setor_empresa->credenciais->count() }}</td>                     
                </tr>
                <tr>
                    <td class="titulo_show">Editar</td>
                    <td>
                        <span class="fa fa-pencil-alt"></span>
                    </td>
                </tr>
                <tr>
                    <td class="titulo_show">Deletar</td>
                    <td> 
                        <span class="fa fa-trash"></span>
                    </td>
                </tr>
                <tr>
                    <td class="titulo_show">Credenciar</td>
                    <td>
                        <i class="fas fa-fw fa-id-card-alt"></i>
                    </td>                    
                </tr>
            </table>
        </div>
    </div>
</div>
<div class="card shadow mb-4">
    <div class="card-header py-3">
        <h6 class="m-0 font-weight-bold text-primary">Taxa</h6>
    </div>
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-bordered" width="100%" cellspacing="0">
                <tr>
                    <td class="titulo_show">Taxa Unitária</td>        
                    <td>
                        {{ Helper::moedaBDtoBR( $evento_periodo_data_setor_empresa->taxa_unitaria ) }}
                    </td>
                </tr>
                <tr>
                    <td class="titulo_show">Taxa Total Estimada</td>        
                    <td>
                        {{ 
                            Helper::moedaBDtoBR( 
                                $evento_periodo_data_setor_empresa->taxa_unitaria * 
                                $evento_periodo_data_setor_empresa->quantidade 
                            ) 
                        }}
                        </td>
                </tr>
                <tr>
                    <td class="titulo_show">Taxa Total</td>        
                    <td>
                        {{ 
                            Helper::moedaBDtoBR( 
                                $evento_periodo_data_setor_empresa->taxa_unitaria * 
                                $evento_periodo_data_setor_empresa->credenciais->count() 
                            ) 
                        }}
                    </td>
                </tr>
                <tr>
                    <td class="titulo_show">Intervalo</td>        
                    <td>{{ $evento_periodo_data_setor_empresa->intervalo->nome }}</td>                
                </tr>
            </table>
        </div>
    </div>
</div>
<div class="card shadow mb-4">
    <div class="card-header py-3">
        <h6 class="m-0 font-weight-bold text-primary">Alimentação</h6>
    </div>
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-bordered" width="100%" cellspacing="0">
                <tr>
                    <td class="titulo_show">Tipo da Alimentação</td>        
                    <td>
                        {{ 
                        $evento_periodo_data_setor_empresa->alimentacao->nome }}</td>
                </tr>
                <tr>
                    <td class="titulo_show">Alimentação Unitária</td>        
                    <td>
                        {{ 
                            Helper::moedaBDtoBR(
                                $evento_periodo_data_setor_empresa->alimentacao->valor_unitario 
                            ) 
                        }}
                    </td>
                </tr>
                <tr>
                    <td class="titulo_show">Alimentação Total Estimada</td>        
                    <td>
                        {{ 
                            Helper::moedaBDtoBR(
                                $evento_periodo_data_setor_empresa->alimentacao->valor_unitario * 
                                $evento_periodo_data_setor_empresa->quantidade 
                            ) 
                        }}
                    </td>
                </tr>
                <tr>
                    <td class="titulo_show">Alimentação Total</td>        
                    <td>
                        {{ 
                            Helper::moedaBDtoBR(
                                $evento_periodo_data_setor_empresa->alimentacao->valor_unitario * 
                                $evento_periodo_data_setor_empresa->credenciais->count()  
                            ) 
                        }}
                    </td>
                </tr>
            </table>
        </div>                    
    </div>
</div>
@endsection 

@section('js')
    <script src="{{ asset('js/adm/funcionario/index-show.js') }}"></script>
@endsection