<strong class="ml-1">Credenciador</strong>
<div class='form-group'>
    {!! Form::select('empresa_id', Helper::getOpcoesSelect('empresa'), null, ['class' => 'form-control mt-1', 'placeholder' => 'Empresa']) !!}
</div>

<strong class="ml-1">Quantidade Máxima de Credenciados Permitida</strong>
<div class='form-group'>
    {!! Form::text('quantidade', null, ['placeholder'=>'Quantidade Máxima de Credenciados Permitida', 'class' => 'form-control']) !!}
</div>

<strong class="ml-1">Taxa Unitária</strong>
<div class='form-group'>
    {!! Form::text('taxa_unitaria', null, ['placeholder'=>'Taxa Unitária', 'class' => 'form-control']) !!}
</div>

<strong class="ml-1">Intervalo</strong>
<div class='form-group'>
    {!! Form::select('intervalo_id', Helper::getOpcoesSelect('intervalo'), null, ['class' => 'form-control mt-1', 'placeholder' => 'Empresa']) !!}
</div>

<strong class="ml-1">Alimentação</strong>
<div class='form-group'>
    {!! Form::select('alimentacao_id', Helper::getOpcoesSelect('alimentacao'), null, ['class' => 'form-control mt-1', 'placeholder' => 'Empresa']) !!}
</div>
