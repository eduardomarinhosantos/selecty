@extends('adm.template.main')

@section('conteudo')

<!-- Page Heading -->
<p class="mb-4">Credenciado criado em 
{{ Helper::datahorarioBDtoBR($funcionario->created_at) }}
e alterado pela última vez em
{{ Helper::datahorarioBDtoBR($funcionario->updated_at) }}
</p>

<!-- DataTales Example -->
<div class="card shadow mb-4">
    <div class="card-header py-3">
        <h6 class="m-0 font-weight-bold text-primary">Dados</h6>
    </div>
    <div class="card-body">
        
        <div class="table-responsive">
            <table class="table table-bordered" width="100%" cellspacing="0">
                <tbody>
                    <tr>
                        <td class="titulo_show"> Nome </td>
                        <td>{{ $funcionario->nome }}</td>
                    </tr>
                    <tr>
                        <td class="titulo_show"> CPF / CNPJ </td>
                        <td>{{ $funcionario->cpf_cnpj }}</td>
                    </tr>
                    <tr>
                        <td class="titulo_show"> RG </td>
                        <td>{{ $funcionario->rg }}</td>
                    </tr>
                    <tr>
                        <td class="titulo_show"> Empresa </td>
                        <td>
                            <a href="{{ route('empresa.show', $funcionario->empresa->id) }}">
                                {{ $funcionario->empresa->nome }}
                            </a>
                        </td>
                    </tr>
                    <tr>
                        <td class="titulo_show"> Função </td>
                        <td>{{ $funcionario->funcao }}</td>
                    </tr>
                    <tr>
                        <td class="titulo_show"> Email </td>
                        <td>{{ $funcionario->email }}</td>
                    </tr>
                    <tr>
                        <td class="titulo_show"> Telefone </td>
                        <td>{{ $funcionario->telefone }}</td>
                    </tr>
                    <tr>
                        <td class="titulo_show"> Observação </td>
                        <td>{{ $funcionario->observacao }}</td>
                    </tr>
                    <tr>
                        <td class="titulo_show">Editar</td>
                        <td>
                            <a href="{{ route('funcionario.edit', $funcionario->id) }}">
                                <span class="fa fa-pencil-alt"></span>
                            </a>
                        </td>
                    </tr>
                    <tr>
                        <td class="titulo_show">Deletar</td>
                        <td>
                            {!! Form::open(['route' => ['funcionario.destroy', $funcionario->id], 'method' => 'DELETE', 'class' => 'form-deletar', 'data-modulo' => 'funcionario']) !!}
                                {{ Form::button('<span class="fa fa-trash"></span>', 
                                    ['type' => 'submit', 'style' => 'color:red', 'class'=>"delete-button"] )  
                                }}                        
                            {!! Form::close() !!}       
                        </td>
                    </tr>
                </tbody>
            </table>
        </div>
    </div>
</div>

<div class="card shadow mb-4">

    <div class="card-header py-3">
        <h6 class="m-0 font-weight-bold text-primary">Eventos</h6>
    </div>
    <div class="card-body">
            
        <div class="table-responsive">
            <table class="table table-bordered display" id="dataTable" width="100%" cellspacing="0">
                <thead>
                    <tr>
                        <th>Nome</th>
                        <th>Local</th>
                        <th>Setor</th>
                        <th>Data</th>
                    </tr>
                </thead>
                <tbody></tbody>
            </table>
        </div>
    </div>
</div>
@endsection 

@section('js')
    <script src="{{ asset('js/adm/funcionario/index-show.js') }}"></script>
@endsection