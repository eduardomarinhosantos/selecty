<div class='form-group'>
    {!! Form::text('nome', null, ['placeholder'=>'Nome', 'class' => 'form-control']) !!}
</div>
<div class='form-group'>
    {!! Form::text('cpf_cnpj', null, ['placeholder'=>'CPF / CNPJ', 'class' => 'form-control']) !!}
</div>
<div class='form-group'>
    {!! Form::text('rg', null, ['placeholder'=>'RG', 'class' => 'form-control']) !!}
</div>
<div class='form-group'>
    {!! Form::select('empresa_id', Helper::getOpcoesSelect('empresa'), null, ['class' => 'form-control']) !!}
</div>
<div class='form-group'>
    {!! Form::text('funcao', null, ['placeholder'=>'Função', 'class' => 'form-control']) !!}
</div>
<div class='form-group'>
    {!! Form::text('email', null, ['placeholder'=>'Email', 'class' => 'form-control']) !!}
</div>
<div class='form-group'>
    {!! Form::text('telefone', null, ['placeholder'=>'Telefone', 'class' => 'form-control']) !!}
</div>
<div class='form-group'>
    {!! Form::textarea('observacao', null, ['placeholder'=>'Observações', 'class' => 'form-control']) !!}
</div>