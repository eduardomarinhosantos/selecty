@extends('adm.template.main')

@section('conteudo')

<!-- Page Heading -->
<p class="mb-4">Editar Credenciado</p>

@include('adm.flash')

<!-- DataTales Example -->
<div class="card shadow mb-4">
    <div class="card-body">
        {!! Form::model($funcionario, ['route' => ['funcionario.update', $funcionario->id], 'method' => 'put', 'id' => 'editar', 'autocomplete' => 'off']) !!}
            @include('adm.funcionario.fields')
            <div class="form-group">
                {!! Form::submit('Editar', ['class' => 'btn btn-primary float-right']) !!}
            </div>
        {!! Form::close() !!}
    </div>
</div>
@endsection 

@section('js')
    <script src="{{ asset('js/adm/funcionario/create-edit.js') }}"></script>
@endsection