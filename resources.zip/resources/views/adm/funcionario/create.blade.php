@extends('adm.template.main')

@section('conteudo')

<!-- Page Heading -->
<p class="mb-4">Inserir um novo Credenciado</p>

@include('adm.flash')

<!-- DataTales Example -->
<div class="card shadow mb-4">
    <div class="card-body">
        {!! Form::open(['route' => 'funcionario.store', 'method' => 'post', 'id' => 'criar', 'autocomplete' => 'off']) !!}
            @include('adm.funcionario.fields')
            <div class="form-group">
                {!! Form::submit('Registrar', ['class' => 'btn btn-primary float-right']) !!}
            </div>
        {!! Form::close() !!}
    </div>
</div>
@endsection 

@section('js')
    <script src="{{ asset('js/adm/funcionario/create-edit.js') }}"></script>
@endsection