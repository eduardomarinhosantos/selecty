@extends('adm.template.main')

@section('conteudo')

<!-- Page Heading -->
<p class="mb-4"></p>

@include('adm.flash')

<!-- DataTales Example -->
<div class="card shadow mb-4">
    <div class="card-header"><h6 class="m-0 mr-1 font-weight-bold text-primary">Editar Setor do Evento</h6></div>
    <div class="card-body">

        <div class="alert alert-info col-md-10">
            Ao remover uma Empresa de um Setor você perderá todas as credenciais feitas até o momento nesse Setor.
        </div>

        {!! Form::open(['route' => ['evento_periodo_data_setor.update', $evento_periodo_data_setor->id], 'method' => 'put', 'id' => 'criar', 'autocomplete' => 'off']) !!}
        
            <div class="row" style="margin-left: 1px;">

            @foreach(
                $evento_periodo_data_setor->evento_periodo_data_setor_empresas
                as $evento_periodo_data_setor_empresa
            ) 
            <div class="card col-md-5 mb-3 mr-3" style="padding: 0px !important;">

                <div class="card-header py-3" >
                    <input type="hidden" value="{{ $evento_periodo_data_setor_empresa->id }}">
                    <h6 class="m-0 font-weight-bold" style="display: inline">{{ $evento_periodo_data_setor_empresa->empresa->nome }}</h6>
                    <i class="fas fa-trash float-right text-primary mt-1"></i>
                </div>    
                <div class="card-body">
                    <div>
                        <strong> Funcionários Permitidos: </strong> 
                        {{ $evento_periodo_data_setor_empresa->quantidade }}
                    </div>
                    <div>
                        <strong> Taxa Unitária: </strong> 
                        {{  Helper::moedaBDtoBR( $evento_periodo_data_setor_empresa->taxa_unitaria ) }}
                    </div>
                    <div>
                        <strong> Alimentação: </strong> 
                        {{  $evento_periodo_data_setor_empresa->alimentacao->nome }}
                        ({{ Helper::moedaBDtoBR( $evento_periodo_data_setor_empresa->alimentacao->valor_unitario ) }})
                    </div>
                    <div>
                        <strong> Intervalo: </strong> 
                        {{ $evento_periodo_data_setor_empresa->intervalo->nome }}
                    </div>
                
                </div>  
            </div>   
            @endforeach
            </div>
            <div class="mb-2 ml-2 mt-5">
                <span class="fas fa-fw fa-building mr-2"></span>
                <strong class="mr-2">Adicionar Empresa</strong>
                <i class="fas fa-fw fa-plus text-primary toggle-evento-setor mt-1" style="color: green !important"></i>
            </div>

            <div id="novas-empresas-container" class="row" style="margin-left: 1px">
                <div class="card col-md-5 empresa-modelo mr-3 mb-3" style="display: none">
                    <div class="card-body">
                        <div class="mb-4">
                            <i class="fas fa-times float-right text-primary mt-1"></i>
                        </div>

                        <strong style="display: block">Empresa</strong>
                        <select class="form-control col-md-11" name="empresa[]">
                            @foreach( $empresas as $empresa )
                                <option value="{{ $empresa->id }}">{{ $empresa->nome }}</option>
                            @endforeach
                        </select>

                        <strong style="display: block" class="mt-3">Alimentação</strong>
                        <select class="form-control col-md-11" name="alimentacao[]">
                            @foreach( $alimentacoes as $alimentacao )
                                <option value="{{ $alimentacao->id }}">{{ $alimentacao->nome }}</option>
                            @endforeach
                        </select>

                        <strong style="display: block" class="mt-3">Intervalo</strong>
                        <select class="form-control col-md-11" name="intervalo[]">
                            @foreach( $intervalos as $intervalo )
                                <option value="{{ $intervalo->id }}">{{ $intervalo->nome }}</option>
                            @endforeach
                        </select>


                        <strong style="display: block" class="mt-3">Taxa Unitária</strong>
                        <input 
                            name="taxa_unitaria[]"
                            type="text" 
                            class="form-control" 
                            style="display: inline" />

                        <strong style="display: block" class="mt-3">Funcionáros Permitidos</strong>
                        <input 
                            name="quantidade[]"
                            type="text" 
                            class="form-control" 
                            style="display: inline" />

                    </div>
                </div>
            </div>        

            <div class="form-group">
                {!! Form::submit('Editar', ['class' => 'btn btn-primary float-right ml-2']) !!}
                <a 
                    class="btn btn-success float-right" 
                    href="{{ 
                            route(
                                'evento.show', 
                                $evento_periodo_data_setor
                                    ->evento_periodo_data
                                    ->evento_periodo
                                    ->evento->id
                            ) 
                        }}">
                    Voltar <i class="fa fa-history"></i>
                </a>
            </div>
        {!! Form::close() !!}
        
    </div>
</div>
@endsection 

@section('js')
    <script src="{{ asset('js/adm/evento_periodo_data_setor/edit.js') }}"></script>
@endsection