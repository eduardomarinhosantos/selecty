export function validaData(s) { // Valida Data no formato "mm-dd-yyyy"
    if ( ! /^\d\d-\d\d-\d\d\d\d$/.test(s) ) return false;
    const parts = s.split('-').map((p) => parseInt(p, 10));
    parts[1] -= 1;
    const d = new Date(parts[2], parts[1], parts[0]);
    return d.getDate() === parts[0] && d.getMonth() === parts[1] && d.getFullYear() === parts[2];
};

export function formataData(data) {
    return data.getDate() + "-" + ( data.getMonth() + 1 ) + "-" + data.getFullYear();
}

export function validaHorario (horario) { 
    return (horario.length == 5) 
        ? 
            ( parseInt( horario.split(':')[0] ) > 23 ? 23 : horario.split(':')[0] ) + ":" + 
            ( parseInt( horario.split(':')[1] ) > 59 ? 59 : horario.split(':')[1] )
        : 
            horario;        
}

export function horarioParaSegundos (horario) { 
    return parseInt( (horario.split(':')[0] * 60) + horario.split(':')[1] ); 
}