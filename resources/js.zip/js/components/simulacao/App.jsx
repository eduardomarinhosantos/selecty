import axios from "axios";
import React, { Component } from 'react';
import ReactDOM from 'react-dom';
import TabPeriodo from './TabPeriodo';
import TabCredenciamento from './TabCredenciamento';
import TabSimulacao from './TabSimulacao';

export default class App extends Component {
    
    constructor(props){

        super(props);

        //Busca valores Armazenados no HTML
        let periodosArray = [];

        let periodos = JSON.parse(document.getElementById('periodos').value);        
        {periodos.map(function(periodo){
            periodosArray[periodo.id] = {
                inicio: null,
                termino: null,
                dias: {}
            };
        })}

        this.state = {

            //Variáveis de Controle
            tab: 1,

            //Credenciamentos
            credenciamentos: {
                periodos: periodosArray,
                local: null
            },
            nomeValido: false,
            localValido: false,
            periodosValidos: false
        }

        //Binding dos Handlers
        this.alternaTab = this.alternaTab.bind(this);
        this.cloneCredenciamentos = this.cloneCredenciamentos.bind(this);  
        this.updateNome = this.updateNome.bind(this);    
        this.updateLocal = this.updateLocal.bind(this);    
        this.updatePeriodo = this.updatePeriodo.bind(this);    
        this.updateSetor = this.updateSetor.bind(this);  
        this.criarEvento = this.criarEvento.bind(this);      
    }

    alternaTab( newTab ) {
        this.setState({
            tab: newTab
        })
    };

    cloneCredenciamentos() {
        return JSON.parse(JSON.stringify(this.state.credenciamentos));
    }

    updateNome(nome) {
        
        if(nome) {
            const credenciamentos = this.cloneCredenciamentos();
            credenciamentos.nome = nome;
            this.setState({ 
                credenciamentos: credenciamentos,
                nomeValido: true
            });
        }
        else this.setState({ nomeValido: false });
    }

    updateLocal(local) {
        
        if(local) {
            const credenciamentos = this.cloneCredenciamentos();
            credenciamentos.local = local;
            this.setState({ 
                credenciamentos: credenciamentos,
                localValido: true
            });
        }
        else this.setState({ localValido: false });
    }

    updatePeriodo(id, periodo) {
        const credenciamentos = this.cloneCredenciamentos();
        credenciamentos.periodos[id] = periodo;
        this.setState({ credenciamentos: credenciamentos }, () => {

            //Valida Periodos
            let periodosValidos = true;
            credenciamentos.periodos.map( (periodo, id) => { 
                if(id && Object.keys(periodo.dias).length === 0) {
                    periodosValidos = false;
                }
            });
            this.setState({ periodosValidos: periodosValidos })
        });
    }

    updateSetor(periodo, data, setorIndex, setor) {
        const credenciamentos = this.cloneCredenciamentos();
        credenciamentos.periodos[periodo].dias[data].setores[setorIndex] = setor;
        this.setState({ credenciamentos: credenciamentos });
    }

    criarEvento() {
        axios.post( `${ window.location.origin }/evento`, {
            token: document.getElementsByName("_token")[0].value,
            credenciamentos: this.state.credenciamentos
        })
        .then(function (response) {
            alert('Evento Criado com Sucesso (Temporário)')
        })
        .catch(function (error) {
            alert('Erro ao Criar Evento (Temporário)')
        });
    }

    render() {

        return (

            <div className="row" style={{marginLeft: '1px'}}>   

                { this.state.tab == 1 && 

                    <TabPeriodo
                        key={'periodo'}
                        alternaTab = { this.alternaTab }

                        nome = { this.state.credenciamentos.nome ? this.state.credenciamentos.nome : ''}
                        updateNome = { this.updateNome }
                        nomeValido = {this.state.nomeValido}

                        local = { this.state.credenciamentos.local ? this.state.credenciamentos.local : ''}
                        updateLocal = { this.updateLocal }
                        localValido = {this.state.localValido}

                        periodos = { this.state.credenciamentos.periodos }
                        periodosValidos = {this.state.periodosValidos}
                        updatePeriodo = { this.updatePeriodo }
                        
                     />
                }
                
                { this.state.tab == 2 && 

                    <TabCredenciamento
                        key={'credenciamento'}                      
                        local = { this.state.credenciamentos.local }
                        periodos = { this.state.credenciamentos.periodos }
                        alternaTab = { this.alternaTab }
                        updateSetor = { this.updateSetor }
                    />
                }         

                { this.state.tab == 3 && 

                    <TabSimulacao
                        key={'simulacao'}
                        credenciamentos = { this.state.credenciamentos }
                        alternaTab = { this.alternaTab }
                        criarEvento = { this.criarEvento }
                    />
                } 
                    
            </div>                
        );
    }
}

if (document.getElementById('app')) {
    ReactDOM.render(<App />, document.getElementById('app'));
}
