import _ from 'lodash';
import React, { Component } from 'react';
import Periodo from './Periodo';

export default class TabPeriodo extends Component {

    constructor(props){
        super(props);

        let periodos = JSON.parse(document.getElementById('periodos').value);
        let locais = JSON.parse(document.getElementById('locais').value);
    
        this.state = {

            periodosArray: periodos,
            periodos: props.periodos,
            locais: locais,
            local: props.local,
            nome: props.nome
        }        

        //Binds
        this.handleNome = this.handleNome.bind(this);
        this.handleLocal = this.handleLocal.bind(this);
        this.retornaPeriodo = this.retornaPeriodo.bind(this);
    }

    retornaPeriodo(id, periodo) {
        this.props.updatePeriodo(id, periodo);
    }

    handleLocal(id) {        
        const local = this.state.locais.filter(local => local.id == id);
        this.setState({ local: id }, () => this.props.updateLocal(local[0]));
    }
    handleNome(nome) {
        this.setState({ nome: nome }, () => this.props.updateNome( nome ));
    }

    render() {

        return (                

            <div  className="card shadow col-md-12 p-0">
                <div className="card-header">Períodos </div>    

                <div className="card-body pr-0 pb-0"  style={{ marginLeft: '10px' }}>
                

                    <strong className="mr-1">Nome do Evento: </strong>
                    <input 
                        type="text" 
                        style={{  display: 'inline'  }} 
                        className="form-control col-md-3 mr-3"
                        value={ this.state.nome }
                        onChange={ (e) => {
                            this.handleNome(e.target.value);
                        }} 
                    />

                    <strong className="mr-1">Local do Evento: </strong>
                    <select 
                        type="text"
                        defaultValue=""
                        className="form-control col-md-4 ml-0"
                        style={{ display: 'inline', marginLeft: '10px' }}
                        value={ this.state.local }
                        onChange={ (e) => {
                            this.handleLocal(e.target.value);
                        }}
                    >
                        <option value="">Selecione um Local</option> 
                        {this.state.locais.map(function(local){
                            return( <option key={local.id} value={local.id}>{local.nome}</option> )
                        })}
                    </select>
                    
                </div> 
                    

                <div className="card-body pl-2 row" style={{ marginLeft: '10px' }}>
              
                    {this.state.periodosArray.map(function(periodo){
                        return (

                            <Periodo
                                key={periodo.id}
                                id={periodo.id}
                                nome={periodo.nome}
                                inicio={
                                    this.state.periodos[periodo.id].inicio
                                        ? this.state.periodos[periodo.id].inicio
                                        : ''
                                }
                                termino={
                                    this.state.periodos[periodo.id].termino
                                        ? this.state.periodos[periodo.id].termino
                                        : ''
                                }
                                retornaPeriodo={this.retornaPeriodo}
                            />
                        )
                    }, this)} 
        
                </div>
                <div className="card-body pl-2">
                    <button 
                        onClick={() => this.props.alternaTab(2)} 
                        disabled={!this.props.periodosValidos || !this.props.nomeValido || !this.props.localValido}
                        className="btn btn-success float-right" 
                        style={{ width: '20%', marginLeft : '3%'}}>
                                Credenciar Empresas                          
                    </button>
                </div>
            </div>
        );
    }
}