import React, { Component } from 'react';

export default class Empresa extends Component {

    constructor(props){

        super(props);

        this.state = {

            //Valores dos Combobox de Controle
            alimentacoesArray: JSON.parse(document.getElementById('alimentacoes').value),
            empresasArray: JSON.parse(document.getElementById('empresas').value),
            intervalosArray: JSON.parse(document.getElementById('intervalos').value),

            id: props.id,
            empresa: props.empresa ? props.empresa : '',
            alimentacao: props.alimentacao ? props.alimentacao : '',
            intervalo: props.intervalo ? props.intervalo : '',
            taxa_unitaria: props.taxa_unitaria ? props.taxa_unitaria : '',
            quantidade: props.quantidade ? props.quantidade : '',
        }

        this.handleEmpresa = this.handleEmpresa.bind(this);
        this.handleAlimentacao = this.handleAlimentacao.bind(this);
        this.handleIntervalo = this.handleIntervalo.bind(this);
        this.handleTaxaUnitaria = this.handleTaxaUnitaria.bind(this);
        this.handleQuantidade = this.handleQuantidade.bind(this);
        this.handleRemoveEmpresa = this.handleRemoveEmpresa.bind(this);        
    }

    handleEmpresa( empresa ) { this.setState({ empresa: empresa }, () => this.retornaEmpresa())}
    handleAlimentacao( alimentacao ) { this.setState({ alimentacao: alimentacao }, () => this.retornaEmpresa())}
    handleIntervalo( intervalo ) { this.setState({ intervalo: intervalo }, () => this.retornaEmpresa())}
    handleTaxaUnitaria( taxa_unitaria ) { this.setState({ taxa_unitaria: taxa_unitaria }, () => this.retornaEmpresa())}
    handleQuantidade( quantidade ) { this.setState({ quantidade: quantidade }, () => this.retornaEmpresa())}
    handleRemoveEmpresa() { this.props.handleRemoveEmpresa( this.state.id )}
    retornaEmpresa() {

        this.props.handleUpdateEmpresas(
            this.state.id, 
            {
                id: this.state.id,
                empresa: this.state.empresa,
                alimentacao: this.state.alimentacao,
                intervalo: this.state.intervalo,
                taxa_unitaria: this.state.taxa_unitaria,
                quantidade: this.state.quantidade
            }
        );
    }

    render() {

        return (
            <div className="card col-md-3 mr-3 mb-3 p-0">

                <div className="card-body">
                    <div className="mb-4">
                        <i 
                            className="fas fa-times float-right text-primary mt-1"
                            onClick={ () => this.handleRemoveEmpresa() }
                        ></i>
                    </div>

                    {/* Empresa */}
                    <strong style={{ display: 'block'}}>Empresa</strong>
                    <select 
                        className="form-control col-md-11" 
                        name="empresa[]"
                        onChange={ e => this.handleEmpresa( e.target.value )}
                        value={ this.state.empresa } >
                        <option value="" disabled> Selecione </option>
                        {this.state.empresasArray.map(function(empresa){
                            return (
                                <option key={empresa.id} value={ empresa.id }>
                                    { empresa.nome }
                                </option>
                            )
                        })}
                    </select>

                    {/* Alimentação */}
                    <strong style={{ display: 'block'}} className="mt-3">Alimentação</strong>
                    <select 
                        className="form-control col-md-11" 
                        name="alimentacao[]"
                        onChange={ e => this.handleAlimentacao( e.target.value )}
                        value={ this.state.alimentacao } >
                        <option value="" disabled> Selecione </option>
                        {this.state.alimentacoesArray.map(function(alimentacao){
                            return (
                                <option key={alimentacao.id} value={ alimentacao.id }>
                                    { alimentacao.nome }
                                </option>
                            )
                        })}
                    </select>

                    {/* Intervalo */}
                    <strong style={{ display: 'block'}} className="mt-3">Intervalo</strong>
                    <select 
                        className="form-control col-md-11" 
                        name="intervalo[]"
                        onChange={ e => this.handleIntervalo( e.target.value )}
                        value={ this.state.intervalo } >
                        <option value="" disabled> Selecione </option>
                        {this.state.intervalosArray.map(function(intervalo){
                            return (
                                <option key={intervalo.id} value={ intervalo.id }>
                                    { intervalo.nome }
                                </option>
                            )
                        })} 
                    </select>

                    {/* Taxa Unitária */}
                    <strong style={{ display: 'block'}} className="mt-3">Taxa Unitária</strong>
                    <input 
                        name="taxa_unitaria[]"
                        type="text" 
                        className="form-control money" 
                        style={{ display: 'inline'}}
                        onChange={ e => this.handleTaxaUnitaria( e.target.value )}
                        value={ this.state.taxa_unitaria } />

                    {/* Funcionários Permitidos (Quantidade) */}
                    <strong style={{ display: 'block'}} className="mt-3">Funcionáros Permitidos</strong>
                    <input 
                        name="quantidade[]"
                        type="text" 
                        className="form-control number" 
                        style={{ display: 'inline'}}
                        onChange={ e => this.handleQuantidade( e.target.value )}
                        value={ this.state.quantidade } />
                </div>
            </div>
        )
    }
}