import axios from "axios";
import React, { Component } from 'react';
import Funcionario from './Funcionario';

export default class Listas extends Component {
    
    constructor(props){

        super(props);

        this.state = {
            
            //Dados de Controle
            evento: props.evento,
            periodo: props.periodo,
            data: props.data,
            setor: props.setor,
            empresa: props.empresa,

            //Lista de Credenciáveis / Credenciados
            listaCredenciaveis: [],
            listaCredenciados: {
                ids: [], ///indexes deixar o filtro mais rápido
                funcionarios: [],
                paginaAtual: []
            },

            //Paginação
            paginacaoCredenciaveis: {
                pagina: 1,
                totalPaginas: 1,
                porPagina: 10
            },
            paginacaoCredenciados: {
                pagina: 1,
                totalPaginas: 1,
                porPagina: 10
            },            
         
            //Busca
            buscaCredenciaveis: {
                nome: '',
                cpfCnpj: '',
                rg: '',
                telefone: ''
            },
            buscaCredenciados: {
                nome: '',
                cpfCnpj: '',
                rg: '',
                telefone: ''
            }
        }

        //Relação
        this.credenciarFuncionario = this.credenciarFuncionario.bind(this);
        this.removerFuncionario = this.removerFuncionario.bind(this);

        //Credenciados
        this.loadCredenciaveis = this.loadCredenciaveis.bind(this);
        this.setPaginaCredenciaveis = this.setPaginaCredenciaveis.bind(this);
        this.handleBuscaCredenciavel = this.handleBuscaCredenciavel.bind(this);
        this.salvarCredenciados = this.salvarCredenciados.bind(this);
        
        //Credenviáveis
        this.updatePaginacaoCredenciados = this.updatePaginacaoCredenciados.bind(this);
        this.setPaginaCredenciados = this.setPaginaCredenciados.bind(this);        
        this.handleBuscaCredenciado = this.handleBuscaCredenciado.bind(this);
    }

    //Carrega Credenciais
    //Atualiza Paginação e Página Atual de Credenciados
    //Carrega e Pagina Credenciaveis ( Eliminando os IDs Credenciados )
    componentDidMount() { 
    
        axios.post( `${ window.location.origin }/credenciais`, 
            {
                evento: this.state.evento,
                periodo: this.state.periodo,
                data: this.state.data,
                setor: this.state.setor,
                empresa: this.state.empresa
            },
            { headers: { 'Content-Type': 'application/json' } }
        )
        .then(function ( credenciados ) {

            this.setState({ listaCredenciados: credenciados.data }, () => {
                this.updatePaginacaoCredenciados()
                this.loadCredenciaveis()
            });
        }.bind( this ))
        .catch(function (error) {
            alert('Erro ao Buscar Credenciais (Temporário)')
        });
    }

    // ###########
    // # Relação #
    // ###########

    /* 
        Move Funcionário da tabela de Credenciáveis para Credenciados
        Recarrega a lista de Credenciáveis chamando o BackEnd ( Caso contrário ficaria buracos nas páginas )
        Atualiza Paginação da tabela de Credenciáveis e Credenciados
        Atualiza Paginação da tabela de Credenciados e Página Atual
    */
    credenciarFuncionario( funcionario ) {

        /* Clona lista e adiciona novo Item */

        const newListaCredenciados =  JSON.parse(JSON.stringify(this.state.listaCredenciados));

        newListaCredenciados['ids'] = [ ...newListaCredenciados['ids'], funcionario.id ], 
        newListaCredenciados['funcionarios'] = [ ...newListaCredenciados['funcionarios'], funcionario ]
        
        this.setState({ listaCredenciados: newListaCredenciados }, () => {
            this.updatePaginacaoCredenciados();
            this.loadCredenciaveis();
         } );
    }

    /* 
        Move Funcionário da tabela de Credenciados para Credenciáveis 
        Recarrega a lista de Credenciáveis chamando o BackEnd ( Caso contrário ficaria buracos nas páginas )
        Atualiza Paginação da tabela de Credenciáveis e Credenciados
        Atualiza Paginação da tabela de Credenciados e Página Atual
    */
    removerFuncionario( funcionario ) {

        /* Clona Lista, Loop na Lista Antiga removendo o item selecionado */

        const listaCredenciados =  JSON.parse(JSON.stringify(this.state.listaCredenciados));
        const newListaCredenciados = { ids: [], funcionarios: [], paginaAtual: [] };

        listaCredenciados['funcionarios'].map(function( funcionarioCredenciado ) { 
            if( funcionarioCredenciado.id !== funcionario.id ) {
                newListaCredenciados['funcionarios'].push( funcionarioCredenciado );
                newListaCredenciados['ids'].push( funcionarioCredenciado.id );
            }
        });             
        
        this.setState({ listaCredenciados: newListaCredenciados }, 
            () => { 
                this.updatePaginacaoCredenciados(),
                this.loadCredenciaveis() 
        } );
    }

    // #################
    // # Credenciaveis #
    // #################

    //Seta página e recarrega funcionarios / paginação
    setPaginaCredenciaveis( pagina ) {

        const newPaginacaoCredenciaveis =  JSON.parse( JSON.stringify( this.state.paginacaoCredenciaveis ) );
        newPaginacaoCredenciaveis.pagina = pagina;

        this.setState({ paginacaoCredenciaveis: { ...newPaginacaoCredenciaveis } }, () => this.loadCredenciaveis() );
    }

    //Seta filtros de buca e recarrega funcionarios / paginação
    handleBuscaCredenciavel( campo, valor ) {

        const buscaCredenciaveis =  JSON.parse( JSON.stringify( this.state.buscaCredenciaveis ) );        
        buscaCredenciaveis[campo] = valor;
        this.setState({ buscaCredenciaveis }, () => this.loadCredenciaveis() );
    }

    //Retorna funcionarios do BackEnd baseado nos filtros selecionados ( Eliminando os IDs Credenciados )
    //Atualiza a paginação 
    loadCredenciaveis() {
        
        axios.post( `${ window.location.origin }/credenciaveis`, 
            {
                empresa: this.state.empresa,
                por_pagina: this.state.paginacaoCredenciaveis.porPagina,
                pagina: this.state.paginacaoCredenciaveis.pagina,
                credenciados: this.state.listaCredenciados[ 'ids' ],

                nome: this.state.buscaCredenciaveis.nome,
                cpfCnpj: this.state.buscaCredenciaveis.cpfCnpj,
                rg: this.state.buscaCredenciaveis.rg,
                telefone: this.state.buscaCredenciaveis.telefone,
            },
            { headers: { 'Content-Type': 'application/json' } }
        )
        .then(function ( credenciaveis ) {

            const newPaginacaoCredenciaveis =  JSON.parse( JSON.stringify( this.state.paginacaoCredenciaveis ) );
            newPaginacaoCredenciaveis.totalPaginas = credenciaveis.data.last_page
            
            this.setState({ 
                listaCredenciaveis: credenciaveis.data.data,    
                paginacaoCredenciaveis: { ...newPaginacaoCredenciaveis }
            });

        }.bind( this ))
        .catch(function (error) {
            alert('Erro ao Buscar Funcionários (Temporário)')
        }); ;
    }

    // ################
    // # Credenciados #
    // ################
    
    //Seta página e recarrega funcionarios / paginação
    setPaginaCredenciados( pagina ) {


        const newPaginacaoCredenciados =  JSON.parse( JSON.stringify( this.state.paginacaoCredenciados ) );
        newPaginacaoCredenciados.pagina = pagina;
        
        this.setState(
            { paginacaoCredenciados: { ...newPaginacaoCredenciados } }, 
            () => this.updatePaginacaoCredenciados() 
        );
    };

    //Atualiza Página Atual e Total de Páginas
    updatePaginacaoCredenciados() {

        const newListaCredenciados = JSON.parse( JSON.stringify(this.state.listaCredenciados) );

        const newPaginacaoCredenciados =  JSON.parse( JSON.stringify( this.state.paginacaoCredenciados ) );       
        newPaginacaoCredenciados.totalPaginas = Math.ceil( 
            this.state.listaCredenciados['ids'].length / this.state.paginacaoCredenciados.porPagina 
        );

        if(
            this.state.buscaCredenciados.nome || this.state.buscaCredenciados.cpfCnpj ||
            this.state.buscaCredenciados.rg || this.state.buscaCredenciados.telefone
        ) {
            newListaCredenciados['paginaAtual'] = JSON.parse( JSON.stringify(this.state.listaCredenciados['funcionarios']));
        }
        else {
            newListaCredenciados['paginaAtual'] = JSON.parse(
                JSON.stringify(this.state.listaCredenciados['funcionarios'])).slice(( 
                this.state.paginacaoCredenciados.pagina - 1 ) * this.state.paginacaoCredenciados.porPagina, 
                this.state.paginacaoCredenciados.pagina * this.state.paginacaoCredenciados.porPagina
            )
        }
        this.setState({ 
            listaCredenciados: newListaCredenciados,
            paginacaoCredenciados: newPaginacaoCredenciados
        })
    }

    //Seta filtros de buca e recarrega página atual
    //IMPROVE: Não há Paginação para o resultado de buscas, o filtro hoje é feito direto na exibição
    handleBuscaCredenciado( campo, valor ) {

        const buscaCredenciados =  JSON.parse( JSON.stringify( this.state.buscaCredenciados ) );        
        buscaCredenciados[campo] = valor;
        this.setState({ buscaCredenciados }, 
            () => this.updatePaginacaoCredenciados() // Repaginação
        );
    }

    salvarCredenciados() {

        axios.post( `${ window.location.origin }/credenciar`, 
            {
                evento: this.state.evento,
                periodo: this.state.periodo,
                data: this.state.data,
                setor: this.state.setor,
                empresa: this.state.empresa,
                credenciados: this.state.listaCredenciados[ 'ids' ]
            },
            { headers: { 'Content-Type': 'application/json' } }
        )
        .then(function ( credenciados ) {
            alert('Credenciais Salvas! (Temporário) ')
        }.bind( this ))
        .catch(function (error) {
            alert('Erro ao Buscar Credenciais (Temporário)')
        });
    }

    render() {
        
        //Gera Páginação Credenciaveis
        let paginasCredenciaveis = [];
        if( this.state.paginacaoCredenciaveis.totalPaginas != 1 ) {
                
            for (let i = 1; i <= this.state.paginacaoCredenciaveis.totalPaginas; i++) {
                
                paginasCredenciaveis.push(
                    
                    this.state.paginacaoCredenciaveis.pagina == i 
                        ?            
                            <li className="paginate_button page-item active }">
                                <span className="page-link">{ i }</span>
                            </li>
                        :
                            <li 
                                className="paginate_button page-item }"
                                onClick={ () => { this.setPaginaCredenciaveis( i ) } }
                            >
                                <span className="page-link">{ i }</span>
                            </li>
                );
            }
        }

        //Gera Páginação Credenciaveis
        let paginasCredenciados = [];
        if( 
            this.state.paginacaoCredenciados.totalPaginas != 1 &&
            !this.state.buscaCredenciados.nome && !this.state.buscaCredenciados.cpfCnpj &&
            !this.state.buscaCredenciados.rg && !this.state.buscaCredenciados.telefone
        ) {
                
            for (let i = 1; i <= this.state.paginacaoCredenciados.totalPaginas; i++) {
                
                paginasCredenciados.push(
                    
                    this.state.paginacaoCredenciados.pagina == i 
                        ?            
                            <li className="paginate_button page-item active }">
                                <span className="page-link">{ i }</span>
                            </li>
                        :
                            <li 
                                className="paginate_button page-item }"
                                onClick={ () => { this.setPaginaCredenciados( i ) } }
                            >
                                <span className="page-link">{ i }</span>
                            </li>
                );
            }
        }

        return (
            <>
                <div className="card shadow mb-4">
                    <div className="card-body">
            
                        <strong>Funcionários</strong>
                        <div class="mt-2">
                            <label class="mb-0 mr-2" >Nome:</label>
                            <input 
                                class="form-control col-md-2 mr-2" 
                                style={{ display: 'inline' }}
                                onChange={ e => this.handleBuscaCredenciavel( 'nome', e.target.value ) }
                            />
                            <label class="mb-0 mr-2" >CPF/CNPJ:</label>
                            <input
                                class="form-control col-md-2 mr-2 cpf_cnpj" 
                                style={{ display: 'inline' }}
                                onChange={ e => this.handleBuscaCredenciavel( 'cpfCnpj', e.target.value ) }
                            />
                            <label class="mb-0 mr-2" >RG:</label>
                            <input 
                                class="form-control col-md-2 mr-2" 
                                style={{ display: 'inline' }}
                                onChange={ e => this.handleBuscaCredenciavel( 'rg', e.target.value.replace(/[-./]/gi, '') ) }
                            />
                            <label class="mb-0 mr-2" >Telefone:</label>
                            <input 
                                class="form-control col-md-2 mr-2 telefone" 
                                style={{ display: 'inline' }}
                                onChange={ e => this.handleBuscaCredenciavel( 'telefone', e.target.value ) }
                            />
                        </div>
                        <table id="funcionarios" className="table table-bordered mt-2">
                            <thead>
                                <tr>
                                    <th>Nome</th>
                                    <th>CPF</th>
                                    <th>RG</th>
                                    <th>Telefone</th>
                                    <th style={{ width: '5%' }}>Credenciar</th>
                                </tr>
                            </thead>
                            <tbody>
                                { this.state.listaCredenciaveis && 
                                    this.state.listaCredenciaveis.map( funcionario => {                                    

                                        return (
                                            <Funcionario
                                                key={ funcionario.id }
                                                id={ funcionario.id }
                                                nome={ funcionario.nome }
                                                cpf_cnpj={ funcionario.cpf_cnpj }
                                                rg={ funcionario.rg }
                                                telefone={ funcionario.telefone }
                                                credenciado={ false }
                                                handleClick={ this.credenciarFuncionario }
                                            />
                                        );
                                })}
                            </tbody>
                        </table>

                        <div className="col-md-12">
                            <div className=" float-right">
                                <div className="dataTables_paginate paging_simple_numbers">
                                    <ul className="pagination">
                                        { paginasCredenciaveis }                                        
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div className="card shadow mb-4">
                    <div className="card-body">
            
                        <strong>Funcionarios Credenciados</strong>
                        <div class="mt-2">
                            <label className="mb-0 mr-2" >Nome:</label>
                            <input 
                                class="form-control col-md-2 mr-2" 
                                style={{ display: 'inline' }}
                                onChange={ e => this.handleBuscaCredenciado( 'nome', e.target.value ) }
                            />
                            <label class="mb-0 mr-2" >CPF/CNPJ:</label>
                            <input
                                class="form-control col-md-2 mr-2 cpf_cnpj" 
                                style={{ display: 'inline' }}
                                onChange={ e => this.handleBuscaCredenciado( 'cpfCnpj', e.target.value ) }
                            />
                            <label class="mb-0 mr-2" >RG:</label>
                            <input 
                                class="form-control col-md-2 mr-2" 
                                style={{ display: 'inline' }}
                                onChange={ e => this.handleBuscaCredenciado( 'rg', e.target.value ) }
                            />
                            <label class="mb-0 mr-2" >Telefone:</label>
                            <input 
                                class="form-control col-md-2 mr-2 telefone" 
                                style={{ display: 'inline' }}
                                onChange={ e => this.handleBuscaCredenciado( 'telefone', e.target.value ) }
                            />
                        </div>
                        <table id="funcionarios" className="table table-bordered mt-2">
                            <thead>
                                <tr>
                                    <th>Nome</th>
                                    <th>CPF</th>
                                    <th>RG</th>
                                    <th>Telefone</th>
                                    <th style={{ width: '5%' }}>Remover</th>
                                </tr>
                            </thead>
                            <tbody>
                                { this.state.listaCredenciados &&
                                    this.state.listaCredenciados['paginaAtual'].map( funcionario => {
                                   
                                    if( this.state.buscaCredenciados.nome )
                                        var regexNome = new RegExp(
                                            `${ this.state.buscaCredenciados.nome.toLocaleLowerCase() }.*`
                                        );

                                    if( this.state.buscaCredenciados.cpfCnpj )
                                        var regexCpfCnpj = new RegExp(
                                            `${ this.state.buscaCredenciados.cpfCnpj }.*`
                                        );

                                    if( this.state.buscaCredenciados.rg )
                                        var regexRg = new RegExp(
                                            `${ this.state.buscaCredenciados.rg.replace(/[-./]/gi, '') }.*`
                                        );

                                    if( this.state.buscaCredenciados.telefone && this.state.buscaCredenciados.telefone != '(')
                                        var regexTelefone = new RegExp(`${ this.state.buscaCredenciados.telefone }.*`);
                                        
                                    if( 
                                        !( regexNome && !funcionario.nome.toLocaleLowerCase().match( regexNome ) ) &&
                                        !( regexCpfCnpj && !funcionario.cpf_cnpj.match( regexCpfCnpj ) ) &&
                                        !( regexRg && !funcionario.rg.replace(/[-./]/gi, '').match( regexRg ) ) &&
                                        !( regexTelefone && !funcionario.telefone.match( regexTelefone ) ) 
                                    ) {

                                    return (
                                        <Funcionario
                                            key={ funcionario.id }
                                            id={ funcionario.id }
                                            nome={ funcionario.nome }
                                            cpf_cnpj={ funcionario.cpf_cnpj }
                                            rg={ funcionario.rg }
                                            telefone={ funcionario.telefone }
                                            credenciado={ true }
                                            handleClick={ this.removerFuncionario }
                                        />
                                    );
                                }
                                })}
                            </tbody>
                        </table>

                        <div className="col-md-12">
                            <div className=" float-right">
                                <div className="dataTables_paginate paging_simple_numbers">
                                    <ul className="pagination">
                                        { paginasCredenciados }                                        
                                    </ul>
                                </div>
                            </div>
                        </div>
            
                    </div>
                    <div class="card-body">
                        <button 
                            className="btn btn-primary float-right"
                            onClick={ () => this.salvarCredenciados() }
                        >Registrar</button>
                    </div>
                </div>
            </>
        );
    }
}