import React, { Component } from 'react';

export default class Funcionario extends Component {
    
    constructor(props){

        super(props);
        
        this.state = {
            id: props.id,
            nome: props.nome,
            cpf_cnpj: props.cpf_cnpj,
            rg: props.rg,
            telefone: props.telefone,
            credenciado: props.credenciado
        }
    }

    render() {

        return (
            
            <tr>
                <td>{ this.state.nome }</td>
                <td>{ this.state.cpf_cnpj }</td>
                <td>{ this.state.rg }</td>
                <td>{ this.state.telefone }</td>
                <td 
                    style={{ color: 'green' }}
                    onClick={ () => this.props.handleClick({
                        id: this.state.id,
                        nome: this.state.nome,
                        cpf_cnpj: this.state.cpf_cnpj,
                        rg: this.state.rg,
                        telefone: this.state.telefone,
                        credenciado: this.state.credenciado
                    })}
                >
                    { this.state.credenciado && <i className="fa fa-times"></i> }
                    { !this.state.credenciado && <i className="fa fa-check"></i> }
                </td>
            </tr>
        );
    }
}